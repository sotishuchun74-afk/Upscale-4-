package com.example.upscaler

import android.os.Bundle
import android.widget.TextView

class GalleryActivity : BaseNavActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_placeholder)
        findViewById<TextView>(R.id.tvPlaceholderTitle).setText(R.string.gallery_title)
        findViewById<TextView>(R.id.tvPlaceholderBody).setText(R.string.gallery_empty)
        setupBottomNav(R.id.nav_gallery)
    }
}

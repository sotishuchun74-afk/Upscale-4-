package com.example.upscaler

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var btnPickVideo: Button
    private lateinit var etMaxFps: EditText
    private lateinit var btnUpscaleVideo: Button
    private lateinit var progressBarVideo: ProgressBar
    private lateinit var tvVideoStatus: TextView

    private var pickedVideoUri: Uri? = null

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                pickedVideoUri = uri
                btnUpscaleVideo.isEnabled = true
                tvVideoStatus.text = "Video tanlandi"
            }
        }

    private val notifPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // Whether granted or not, the foreground service still works —
            // without the permission it just won't show a visible notification
            // on Android 13+. We start it either way.
            startServiceForPicked()
        }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                UpscaleService.ACTION_PROGRESS -> {
                    val msg = intent.getStringExtra(UpscaleService.EXTRA_MESSAGE) ?: ""
                    tvVideoStatus.text = msg
                }
                UpscaleService.ACTION_DONE -> {
                    setBusy(false, "Tayyor! Galereyaga saqlandi.")
                    Toast.makeText(this@MainActivity, "Video Galereyaga saqlandi", Toast.LENGTH_LONG).show()
                }
                UpscaleService.ACTION_ERROR -> {
                    val msg = intent.getStringExtra(UpscaleService.EXTRA_MESSAGE)
                    setBusy(false, "Xatolik: $msg")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnPickVideo = findViewById(R.id.btnPickVideo)
        etMaxFps = findViewById(R.id.etMaxFps)
        btnUpscaleVideo = findViewById(R.id.btnUpscaleVideo)
        progressBarVideo = findViewById(R.id.progressBarVideo)
        tvVideoStatus = findViewById(R.id.tvVideoStatus)

        btnPickVideo.setOnClickListener {
            pickVideoLauncher.launch("video/*")
        }

        btnUpscaleVideo.setOnClickListener {
            if (pickedVideoUri == null) {
                Toast.makeText(this, "Avval video tanlang", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                startServiceForPicked()
            }
        }

        if (UpscaleService.isRunning) {
            setBusy(true, UpscaleService.lastStatus)
        }
    }

    private fun startServiceForPicked() {
        val uri = pickedVideoUri ?: return
        val maxFps = etMaxFps.text.toString().toFloatOrNull()?.coerceIn(1f, 60f) ?: 30f
        val intent = Intent(this, UpscaleService::class.java).apply {
            putExtra(UpscaleService.EXTRA_VIDEO_URI, uri.toString())
            putExtra(UpscaleService.EXTRA_MAX_FPS, maxFps)
        }
        ContextCompat.startForegroundService(this, intent)
        setBusy(true, "Boshlandi (fon xizmati orqali ishlaydi)...")
    }

    private fun setBusy(busy: Boolean, msg: String) {
        progressBarVideo.visibility = if (busy) android.view.View.VISIBLE else android.view.View.GONE
        btnUpscaleVideo.isEnabled = !busy
        btnPickVideo.isEnabled = !busy
        tvVideoStatus.text = msg
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(UpscaleService.ACTION_PROGRESS)
            addAction(UpscaleService.ACTION_DONE)
            addAction(UpscaleService.ACTION_ERROR)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(statusReceiver, filter)
        }
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(statusReceiver)
    }
}

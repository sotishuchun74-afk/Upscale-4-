package com.example.upscaler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.progressindicator.LinearProgressIndicator

class MainActivity : BaseNavActivity() {

    private lateinit var btnPickVideo: Button
    private lateinit var etMaxFps: EditText
    private lateinit var spinnerQuality: Spinner
    private lateinit var spinnerModel: Spinner
    private lateinit var btnSettings: Button
    private lateinit var btnStartResume: Button
    private lateinit var btnPause: Button
    private lateinit var listJobs: ListView

    private val qualityLabels = arrayOf("720p", "1080p", "2K", "4K")
    private val qualityLongSides = intArrayOf(1280, 1920, 2560, 3840)

    private var availableModels: List<UpscaleModel> = emptyList()

    private lateinit var jobsAdapter: JobsAdapter

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                    // Some providers don't support persistable permissions; we still
                    // try to proceed, it just might not survive a full app restart.
                }
                val name = getDisplayName(uri)
                val quality = qualityLongSides[spinnerQuality.selectedItemPosition]
                val fps = etMaxFps.text.toString().toFloatOrNull()?.coerceIn(1f, 60f) ?: 30f
                val modelId = availableModels.getOrNull(spinnerModel.selectedItemPosition)?.id
                    ?: ModelManager.BUILT_IN_ID
                QueueManager.addJob(this, uri.toString(), name, quality, fps, modelId)
                refreshJobs()
                Toast.makeText(this, R.string.toast_added_to_queue, Toast.LENGTH_SHORT).show()
            }
        }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                UpscaleService.ACTION_DONE -> {
                    val name = intent.getStringExtra(UpscaleService.EXTRA_DISPLAY_NAME)
                    Toast.makeText(this@MainActivity, getString(R.string.toast_upscale_done, name), Toast.LENGTH_LONG).show()
                }
                UpscaleService.ACTION_ERROR -> {
                    val msg = intent.getStringExtra(UpscaleService.EXTRA_MESSAGE)
                    Toast.makeText(this@MainActivity, getString(R.string.toast_error_prefix, msg), Toast.LENGTH_LONG).show()
                }
            }
            refreshJobs()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupBottomNav(R.id.nav_home)

        btnPickVideo = findViewById(R.id.btnPickVideo)
        etMaxFps = findViewById(R.id.etMaxFps)
        spinnerQuality = findViewById(R.id.spinnerQuality)
        spinnerModel = findViewById(R.id.spinnerModel)
        btnSettings = findViewById(R.id.btnSettings)
        btnStartResume = findViewById(R.id.btnStartResume)
        btnPause = findViewById(R.id.btnPause)
        listJobs = findViewById(R.id.listJobs)

        spinnerQuality.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, qualityLabels)
        spinnerQuality.setSelection(1)

        refreshModelSpinner()
        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        jobsAdapter = JobsAdapter(this, mutableListOf())
        listJobs.adapter = jobsAdapter

        btnPickVideo.setOnClickListener {
            pickVideoLauncher.launch(arrayOf("video/*"))
        }

        btnStartResume.setOnClickListener {
            val intent = Intent(this, UpscaleService::class.java)
            ContextCompat.startForegroundService(this, intent)
            Toast.makeText(this, R.string.toast_queue_started, Toast.LENGTH_SHORT).show()
        }

        btnPause.setOnClickListener {
            val intent = Intent(this, UpscaleService::class.java).apply {
                action = UpscaleService.ACTION_PAUSE
            }
            startService(intent)
            Toast.makeText(this, R.string.toast_pause_requested, Toast.LENGTH_SHORT).show()
        }

        refreshJobs()
    }

    private fun refreshModelSpinner() {
        val previouslySelectedId = availableModels.getOrNull(spinnerModel.selectedItemPosition)?.id
        availableModels = ModelManager.getModels(this)
        spinnerModel.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, availableModels.map { it.name }
        )
        val restoredIndex = availableModels.indexOfFirst { it.id == previouslySelectedId }
        spinnerModel.setSelection(if (restoredIndex >= 0) restoredIndex else 0)
    }

    private fun refreshJobs() {
        val jobs = QueueManager.getJobs(this)
        jobsAdapter.clear()
        jobsAdapter.addAll(jobs)
        jobsAdapter.notifyDataSetChanged()
    }

    private fun getDisplayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "video"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
        }
        return name
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(UpscaleService.ACTION_PROGRESS)
            addAction(UpscaleService.ACTION_QUEUE_CHANGED)
            addAction(UpscaleService.ACTION_DONE)
            addAction(UpscaleService.ACTION_ERROR)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(statusReceiver, filter)
        }
        refreshModelSpinner()
        refreshJobs()
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(statusReceiver)
    }

    inner class JobsAdapter(context: Context, jobs: MutableList<Job>) :
        ArrayAdapter<Job>(context, 0, jobs) {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(context)
                .inflate(R.layout.item_job, parent, false)
            val job = getItem(position)!!
            val tvInfo = view.findViewById<TextView>(R.id.tvJobInfo)
            val tvStatus = view.findViewById<TextView>(R.id.tvJobStatus)
            val progress = view.findViewById<LinearProgressIndicator>(R.id.progressJob)
            val btnRemove = view.findViewById<Button>(R.id.btnRemoveJob)
            val btnCompare = view.findViewById<Button>(R.id.btnCompareJob)

            val statusText = when (job.status) {
                JobStatus.QUEUED -> getString(R.string.job_status_queued)
                JobStatus.PROCESSING -> getString(R.string.job_status_processing)
                JobStatus.PAUSED -> getString(R.string.job_status_paused)
                JobStatus.DONE -> getString(R.string.job_status_done)
                JobStatus.ERROR -> getString(R.string.job_status_error, job.errorMessage ?: "")
            }
            val progressText = if (job.frameCount > 0) {
                " (" + job.nextFrameIndex + "/" + job.frameCount + ")"
            } else ""
            val modelName = ModelManager.getModel(context, job.modelId)?.name ?: job.modelId
            tvInfo.text = job.displayName + " [" + modelName + "]"
            tvStatus.text = statusText + progressText

            val statusColorRes = when (job.status) {
                JobStatus.DONE -> R.color.status_done
                JobStatus.PROCESSING -> R.color.status_processing
                JobStatus.ERROR -> R.color.status_error
                JobStatus.PAUSED -> R.color.status_paused
                JobStatus.QUEUED -> R.color.status_queued
            }
            tvStatus.setTextColor(ContextCompat.getColor(context, statusColorRes))

            if (job.frameCount > 0) {
                progress.isIndeterminate = false
                progress.max = job.frameCount
                progress.setProgressCompat(job.nextFrameIndex.coerceIn(0, job.frameCount), false)
            } else if (job.status == JobStatus.PROCESSING) {
                progress.isIndeterminate = true
            } else {
                progress.isIndeterminate = false
                progress.max = 1
                progress.setProgressCompat(if (job.status == JobStatus.DONE) 1 else 0, false)
            }

            if (job.status == JobStatus.DONE && job.outputUri != null) {
                btnCompare.visibility = View.VISIBLE
                btnCompare.setOnClickListener {
                    val intent = Intent(context, ComparisonActivity::class.java).apply {
                        putExtra(ComparisonActivity.EXTRA_ORIGINAL_URI, job.videoUri)
                        putExtra(ComparisonActivity.EXTRA_UPSCALED_URI, job.outputUri)
                        putExtra(ComparisonActivity.EXTRA_TITLE, job.displayName)
                    }
                    context.startActivity(intent)
                }
            } else {
                btnCompare.visibility = View.GONE
                btnCompare.setOnClickListener(null)
            }

            btnRemove.isEnabled = job.status != JobStatus.PROCESSING
            btnRemove.setOnClickListener {
                if (job.status != JobStatus.PROCESSING) {
                    QueueManager.removeJob(context, job.id)
                    refreshJobs()
                } else {
                    Toast.makeText(
                        context,
                        R.string.toast_cannot_remove_processing,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            return view
        }
    }
}

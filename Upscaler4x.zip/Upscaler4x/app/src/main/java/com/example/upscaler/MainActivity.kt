package com.example.upscaler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var btnPickVideo: Button
    private lateinit var etMaxFps: EditText
    private lateinit var spinnerQuality: Spinner
    private lateinit var btnStartResume: Button
    private lateinit var btnPause: Button
    private lateinit var listJobs: ListView

    private val qualityLabels = arrayOf("720p", "1080p", "2K", "4K")
    private val qualityLongSides = intArrayOf(1280, 1920, 2560, 3840)

    private lateinit var jobsAdapter: JobsAdapter

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                    // Some providers don't support persistable permissions; we still
                    // try to proceed, it just might not survive a full app restart.
                }
                val name = getDisplayName(uri)
                val quality = qualityLongSides[spinnerQuality.selectedItemPosition]
                val fps = etMaxFps.text.toString().toFloatOrNull()?.coerceIn(1f, 60f) ?: 30f
                QueueManager.addJob(this, uri.toString(), name, quality, fps)
                refreshJobs()
                Toast.makeText(this, "Navbatga qo'shildi", Toast.LENGTH_SHORT).show()
            }
        }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                UpscaleService.ACTION_DONE -> {
                    val name = intent.getStringExtra(UpscaleService.EXTRA_DISPLAY_NAME)
                    Toast.makeText(this@MainActivity, "$name tayyor, Galereyaga saqlandi", Toast.LENGTH_LONG).show()
                }
                UpscaleService.ACTION_ERROR -> {
                    val msg = intent.getStringExtra(UpscaleService.EXTRA_MESSAGE)
                    Toast.makeText(this@MainActivity, "Xatolik: $msg", Toast.LENGTH_LONG).show()
                }
            }
            refreshJobs()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnPickVideo = findViewById(R.id.btnPickVideo)
        etMaxFps = findViewById(R.id.etMaxFps)
        spinnerQuality = findViewById(R.id.spinnerQuality)
        btnStartResume = findViewById(R.id.btnStartResume)
        btnPause = findViewById(R.id.btnPause)
        listJobs = findViewById(R.id.listJobs)

        spinnerQuality.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, qualityLabels)
        spinnerQuality.setSelection(1)

        jobsAdapter = JobsAdapter(this, mutableListOf())
        listJobs.adapter = jobsAdapter

        btnPickVideo.setOnClickListener {
            pickVideoLauncher.launch(arrayOf("video/*"))
        }

        btnStartResume.setOnClickListener {
            val intent = Intent(this, UpscaleService::class.java)
            ContextCompat.startForegroundService(this, intent)
            Toast.makeText(this, "Navbat ishga tushdi", Toast.LENGTH_SHORT).show()
        }

        btnPause.setOnClickListener {
            val intent = Intent(this, UpscaleService::class.java).apply {
                action = UpscaleService.ACTION_PAUSE
            }
            startService(intent)
            Toast.makeText(this, "Pauza so'raldi (joriy kadrdan keyin to'xtaydi)", Toast.LENGTH_SHORT).show()
        }

        refreshJobs()
    }

    private fun refreshJobs() {
        val jobs = QueueManager.getJobs(this)
        jobsAdapter.clear()
        jobsAdapter.addAll(jobs)
        jobsAdapter.notifyDataSetChanged()
    }

    private fun getDisplayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "video"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
        }
        return name
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(UpscaleService.ACTION_PROGRESS)
            addAction(UpscaleService.ACTION_QUEUE_CHANGED)
            addAction(UpscaleService.ACTION_DONE)
            addAction(UpscaleService.ACTION_ERROR)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(statusReceiver, filter)
        }
        refreshJobs()
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(statusReceiver)
    }

    inner class JobsAdapter(context: Context, jobs: MutableList<Job>) :
        ArrayAdapter<Job>(context, 0, jobs) {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(context)
                .inflate(R.layout.item_job, parent, false)
            val job = getItem(position)!!
            val tvInfo = view.findViewById<TextView>(R.id.tvJobInfo)
            val btnRemove = view.findViewById<Button>(R.id.btnRemoveJob)

            val statusText = when (job.status) {
                JobStatus.QUEUED -> "Navbatda"
                JobStatus.PROCESSING -> "Ishlanmoqda"
                JobStatus.PAUSED -> "Pauzada"
                JobStatus.DONE -> "Tayyor"
                JobStatus.ERROR -> "Xatolik: " + (job.errorMessage ?: "")
            }
            val progressText = if (job.frameCount > 0) {
                " (" + job.nextFrameIndex + "/" + job.frameCount + ")"
            } else ""
            tvInfo.text = job.displayName + "\n" + statusText + progressText

            btnRemove.isEnabled = job.status != JobStatus.PROCESSING
            btnRemove.setOnClickListener {
                if (job.status != JobStatus.PROCESSING) {
                    QueueManager.removeJob(context, job.id)
                    refreshJobs()
                } else {
                    Toast.makeText(
                        context,
                        "Hozir ishlanayotgan videoni o'chira olmaysiz, avval pauza qiling",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            return view
        }
    }
}

package com.example.upscaler

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import android.provider.MediaStore
import java.io.File
import java.nio.FloatBuffer

/**
 * Runs the video upscale pipeline as a foreground service, so it keeps
 * running even when the screen is off or the app is backgrounded — this is
 * what a plain background Thread inside an Activity cannot reliably do,
 * since Android suspends that work once the app is no longer in the
 * foreground.
 */
class UpscaleService : Service() {

    companion object {
        private const val CHANNEL_ID = "upscale_channel"
        private const val NOTIF_ID = 1001

        const val EXTRA_VIDEO_URI = "extra_video_uri"
        const val EXTRA_MAX_FPS = "extra_max_fps"
        const val EXTRA_TARGET_LONG_SIDE = "extra_target_long_side"
        const val EXTRA_MESSAGE = "extra_message"

        const val ACTION_PROGRESS = "com.example.upscaler.PROGRESS"
        const val ACTION_DONE = "com.example.upscaler.DONE"
        const val ACTION_ERROR = "com.example.upscaler.ERROR"

        @Volatile var isRunning: Boolean = false
        @Volatile var lastStatus: String = ""
    }

    private var ortEnv: OrtEnvironment? = null
    private var ortSessionVideo: OrtSession? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private val TILE_SIZE = 96
    private val OVERLAP = 8
    private val SCALE = 4
    private val VIDEO_MODEL_FILE = "realesr-animevideov3.onnx"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (isRunning) {
            // A job is already in progress; ignore duplicate start requests
            // (Batch B will turn this into a proper queue).
            return START_NOT_STICKY
        }

        val uriStr = intent?.getStringExtra(EXTRA_VIDEO_URI)
        val maxFps = intent?.getFloatExtra(EXTRA_MAX_FPS, 30f) ?: 30f
        val targetLongSide = intent?.getIntExtra(EXTRA_TARGET_LONG_SIDE, 1920) ?: 1920
        if (uriStr == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val uri = Uri.parse(uriStr)

        createChannel()
        isRunning = true
        startForeground(NOTIF_ID, buildNotification("Boshlanmoqda...", 0))

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Upscaler4x::ProcessingWakeLock")
        wakeLock?.acquire(8 * 60 * 60 * 1000L) // 8h safety cap in case something hangs

        Thread {
            try {
                ensureVideoSession()
                val outFile = processVideo(uri, maxFps, targetLongSide) { msg, pct ->
                    lastStatus = msg
                    updateNotification(msg, pct)
                    broadcastProgress(msg)
                }
                saveVideoToGallery(outFile)
                lastStatus = "Tayyor! Galereyaga saqlandi."
                updateNotification(lastStatus, 100)
                sendBroadcast(Intent(ACTION_DONE).setPackage(packageName))
            } catch (e: Exception) {
                lastStatus = "Xatolik: ${e.message}"
                updateNotification(lastStatus, 0)
                sendBroadcast(Intent(ACTION_ERROR).apply {
                    putExtra(EXTRA_MESSAGE, e.message)
                    setPackage(packageName)
                })
            } finally {
                isRunning = false
                wakeLock?.let { if (it.isHeld) it.release() }
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }.start()

        return START_NOT_STICKY
    }

    private fun broadcastProgress(msg: String) {
        sendBroadcast(Intent(ACTION_PROGRESS).apply {
            putExtra(EXTRA_MESSAGE, msg)
            setPackage(packageName)
        })
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID, "Video Upscale", NotificationManager.IMPORTANCE_LOW
            )
            mgr.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String, progress: Int): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Video kattalashtirilmoqda")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setProgress(100, progress, progress == 0)
            .build()
    }

    private fun updateNotification(text: String, progress: Int) {
        val mgr = getSystemService(NotificationManager::class.java)
        mgr.notify(NOTIF_ID, buildNotification(text, progress))
    }

    private fun ensureVideoSession() {
        if (ortSessionVideo != null) return
        val env = ortEnv ?: OrtEnvironment.getEnvironment()
        val bytes = assets.open(VIDEO_MODEL_FILE).readBytes()
        val options = OrtSession.SessionOptions()
        val session = env.createSession(bytes, options)
        ortEnv = env
        ortSessionVideo = session
    }

    /** Inserts the finished file into the device's Gallery (Movies collection). */
    private fun saveVideoToGallery(file: File): Uri? {
        val resolver = contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Upscaler4x")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
        val itemUri = resolver.insert(collection, values) ?: return null
        resolver.openOutputStream(itemUri)?.use { out ->
            file.inputStream().use { input -> input.copyTo(out) }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(itemUri, values, null, null)
        } else {
            sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, itemUri))
        }
        return itemUri
    }

    // ---------------------------------------------------------------
    // Tiling / tensor helpers (unchanged from before)
    // ---------------------------------------------------------------

    private fun upscaleWithTiling(
        input: Bitmap,
        session: OrtSession,
        onProgress: (Int, Int) -> Unit
    ): Bitmap {
        val w = input.width
        val h = input.height
        val outBitmap = Bitmap.createBitmap(w * SCALE, h * SCALE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outBitmap)

        val tilesX = (w + TILE_SIZE - 1) / TILE_SIZE
        val tilesY = (h + TILE_SIZE - 1) / TILE_SIZE
        val totalTiles = tilesX * tilesY
        var doneTiles = 0

        var y = 0
        while (y < h) {
            val tileH = minOf(TILE_SIZE, h - y)
            var x = 0
            while (x < w) {
                val tileW = minOf(TILE_SIZE, w - x)

                val padLeft = minOf(OVERLAP, x)
                val padTop = minOf(OVERLAP, y)
                val padRight = minOf(OVERLAP, w - (x + tileW))
                val padBottom = minOf(OVERLAP, h - (y + tileH))

                val cropX = x - padLeft
                val cropY = y - padTop
                val cropW = tileW + padLeft + padRight
                val cropH = tileH + padTop + padBottom

                val tileBitmap = Bitmap.createBitmap(input, cropX, cropY, cropW, cropH)
                val outTile = runModelOnTile(tileBitmap, session)

                val srcLeft = padLeft * SCALE
                val srcTop = padTop * SCALE
                val srcW = tileW * SCALE
                val srcH = tileH * SCALE
                val finalTile = Bitmap.createBitmap(outTile, srcLeft, srcTop, srcW, srcH)

                canvas.drawBitmap(finalTile, (x * SCALE).toFloat(), (y * SCALE).toFloat(), null)

                doneTiles++
                onProgress(doneTiles, totalTiles)

                x += tileW
            }
            y += tileH
        }
        return outBitmap
    }

    private fun runModelOnTile(bitmap: Bitmap, session: OrtSession): Bitmap {
        val env = ortEnv!!
        val inputTensor = bitmapToTensor(bitmap, env)
        inputTensor.use { tensor ->
            val inputs = mapOf("input" to tensor)
            session.run(inputs).use { result ->
                val outputTensor = result[0] as OnnxTensor
                return tensorToBitmap(outputTensor)
            }
        }
    }

    private fun bitmapToTensor(bitmap: Bitmap, env: OrtEnvironment): OnnxTensor {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val floatBuffer = FloatBuffer.allocate(3 * w * h)
        val rArr = FloatArray(w * h)
        val gArr = FloatArray(w * h)
        val bArr = FloatArray(w * h)
        for (i in 0 until w * h) {
            val p = pixels[i]
            rArr[i] = ((p shr 16) and 0xFF) / 255f
            gArr[i] = ((p shr 8) and 0xFF) / 255f
            bArr[i] = (p and 0xFF) / 255f
        }
        floatBuffer.put(rArr)
        floatBuffer.put(gArr)
        floatBuffer.put(bArr)
        floatBuffer.rewind()

        val shape = longArrayOf(1, 3, h.toLong(), w.toLong())
        return OnnxTensor.createTensor(env, floatBuffer, shape)
    }

    private fun tensorToBitmap(tensor: OnnxTensor): Bitmap {
        val shape = tensor.info.shape
        val h = shape[2].toInt()
        val w = shape[3].toInt()
        val size = h * w

        val buffer = tensor.floatBuffer
        val rArr = FloatArray(size)
        val gArr = FloatArray(size)
        val bArr = FloatArray(size)
        buffer.get(rArr)
        buffer.get(gArr)
        buffer.get(bArr)

        val pixels = IntArray(size)
        for (i in 0 until size) {
            val r = (rArr[i].coerceIn(0f, 1f) * 255).toInt()
            val g = (gArr[i].coerceIn(0f, 1f) * 255).toInt()
            val b = (bArr[i].coerceIn(0f, 1f) * 255).toInt()
            pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }

        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, w, 0, 0, w, h)
        return bmp
    }

    // ---------------------------------------------------------------
    // Video pipeline — same as before, minus the frame cap, plus
    // progress-percent reporting for the notification.
    // ---------------------------------------------------------------

    private fun processVideo(
        uri: Uri,
        maxFps: Float,
        targetLongSide: Int,
        onProgress: (String, Int) -> Unit
    ): File {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(this, uri)

        var srcW = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            ?.toIntOrNull() ?: 0
        var srcH = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            ?.toIntOrNull() ?: 0
        val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
            ?.toIntOrNull() ?: 0
        if (rotation == 90 || rotation == 270) {
            val tmp = srcW; srcW = srcH; srcH = tmp
        }
        val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            ?.toLongOrNull() ?: 0L

        var srcFps = 24f
        var audioTrackIndex = -1
        var audioFormat: MediaFormat? = null
        val probe = MediaExtractor()
        probe.setDataSource(this, uri, null)
        for (i in 0 until probe.trackCount) {
            val fmt = probe.getTrackFormat(i)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/") && fmt.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                srcFps = fmt.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat()
            }
            if (mime.startsWith("audio/") && audioTrackIndex == -1) {
                audioTrackIndex = i
                audioFormat = fmt
            }
        }
        probe.release()

        val outFps = srcFps.coerceAtMost(maxFps).coerceAtLeast(1f)
        val frameIntervalUs = (1_000_000f / outFps).toLong()
        val totalDurationUs = durationMs * 1000L
        // No VIDEO_MAX_FRAMES cap anymore — the full video is processed.
        val frameCount = (totalDurationUs / frameIntervalUs).toInt() + 1

        // The model always does a fixed 4x upscale. To land on the user's chosen
        // output resolution (e.g. 1080p -> long side 1920), we need to feed it
        // an input whose long side is targetLongSide / SCALE. If the source is
        // already smaller than that, we don't downscale further (no point —
        // that would only lose detail, not add any).
        val processCap = targetLongSide / SCALE
        val longSide = maxOf(srcW, srcH).coerceAtLeast(1)
        val downscale = if (longSide > processCap) processCap.toFloat() / longSide else 1f
        val procW = (srcW * downscale).toInt().coerceAtLeast(16)
        val procH = (srcH * downscale).toInt().coerceAtLeast(16)
        var outW = ((procW * SCALE) / 16) * 16
        var outH = ((procH * SCALE) / 16) * 16

        val encoder = MediaCodec.createEncoderByType("video/avc")

        // Query what this specific device's encoder actually supports and
        // clamp down to it if needed, instead of guessing a profile/level
        // that may not match the real hardware limits.
        try {
            val videoCaps = encoder.codecInfo.getCapabilitiesForType("video/avc").videoCapabilities
            if (!videoCaps.isSizeSupported(outW, outH)) {
                var scale = 0.95
                while (scale > 0.3) {
                    val w = ((outW * scale).toInt() / 16) * 16
                    val h = ((outH * scale).toInt() / 16) * 16
                    if (w > 0 && h > 0 && videoCaps.isSizeSupported(w, h)) {
                        outW = w
                        outH = h
                        break
                    }
                    scale -= 0.05
                }
            }
        } catch (e: Exception) {
            // If the capability query itself isn't available, fall through
            // and let configure() below report whatever it reports.
        }

        val outputFormat = MediaFormat.createVideoFormat("video/avc", outW, outH).apply {
            setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            )
            setInteger(MediaFormat.KEY_BIT_RATE, outW * outH * 4)
            setInteger(MediaFormat.KEY_FRAME_RATE, outFps.toInt().coerceAtLeast(1))
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh)
            setInteger(MediaFormat.KEY_LEVEL, MediaCodecInfo.CodecProfileLevel.AVCLevel51)
        }
        try {
            encoder.configure(outputFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        } catch (e: Exception) {
            throw RuntimeException(
                "Video kodlovchi ${outW}x${outH} o'lchamni qo'llab-quvvatlamayapti " +
                    "(${e.javaClass.simpleName}: ${e.message ?: "tafsilot yo'q"})"
            )
        }
        val inputSurface = encoder.createInputSurface()
        encoder.start()
        val glPipe = GlEncoderPipeline(inputSurface)

        val outputFile = File(getExternalFilesDir(null), "upscaled_${System.currentTimeMillis()}.mp4")
        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxerVideoTrack = -1
        var muxerAudioTrack = -1
        var muxerStarted = false
        val bufferInfo = MediaCodec.BufferInfo()
        var pts = 0L

        fun drainEncoder(endOfStream: Boolean) {
            if (endOfStream) encoder.signalEndOfInputStream()
            while (true) {
                val outIndex = encoder.dequeueOutputBuffer(bufferInfo, 10_000)
                when {
                    outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!endOfStream) return
                    }
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        muxerVideoTrack = muxer.addTrack(encoder.outputFormat)
                        if (audioFormat != null) {
                            muxerAudioTrack = muxer.addTrack(audioFormat!!)
                        }
                        muxer.start()
                        muxerStarted = true
                    }
                    outIndex >= 0 -> {
                        val encodedData = encoder.getOutputBuffer(outIndex)
                        if (encodedData != null && bufferInfo.size > 0 && muxerStarted) {
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            muxer.writeSampleData(muxerVideoTrack, encodedData, bufferInfo)
                        }
                        encoder.releaseOutputBuffer(outIndex, false)
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                }
            }
        }

        for (frameIdx in 0 until frameCount) {
            val timeUs = frameIdx * frameIntervalUs
            val rawFrame = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                ?: continue
            val resized = Bitmap.createScaledBitmap(rawFrame, procW, procH, true)
            var upscaled = upscaleWithTiling(resized, ortSessionVideo!!) { _, _ -> }
            if (upscaled.width != outW || upscaled.height != outH) {
                upscaled = Bitmap.createScaledBitmap(upscaled, outW, outH, true)
            }

            glPipe.drawFrame(upscaled, pts * 1000L)
            drainEncoder(false)

            pts += frameIntervalUs
            val pct = ((frameIdx + 1) * 100 / frameCount)
            onProgress("Kadr ${frameIdx + 1}/$frameCount", pct)
        }
        drainEncoder(true)
        encoder.stop()
        encoder.release()
        glPipe.release()
        inputSurface.release()

        if (audioTrackIndex != -1 && muxerAudioTrack != -1) {
            onProgress("Ovoz qo'shilmoqda...", 100)
            val audioExtractor = MediaExtractor()
            audioExtractor.setDataSource(this, uri, null)
            audioExtractor.selectTrack(audioTrackIndex)
            val buffer = java.nio.ByteBuffer.allocate(1_048_576)
            val audioBufferInfo = MediaCodec.BufferInfo()
            while (true) {
                val sampleSize = audioExtractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                audioBufferInfo.offset = 0
                audioBufferInfo.size = sampleSize
                audioBufferInfo.presentationTimeUs = audioExtractor.sampleTime
                audioBufferInfo.flags = audioExtractor.sampleFlags
                muxer.writeSampleData(muxerAudioTrack, buffer, audioBufferInfo)
                audioExtractor.advance()
            }
            audioExtractor.release()
        }

        muxer.stop()
        muxer.release()
        retriever.release()

        return outputFile
    }

    override fun onDestroy() {
        super.onDestroy()
        ortSessionVideo?.close()
        ortEnv?.close()
        wakeLock?.let { if (it.isHeld) it.release() }
    }
}

/**
 * Renders bitmaps onto a MediaCodec encoder's input Surface via OpenGL ES,
 * with an explicit presentation timestamp per frame (set via
 * eglPresentationTimeANDROID). This avoids relying on wall-clock timing,
 * which would otherwise bake the (slow, variable) model inference time into
 * the output video's playback speed.
 */
class GlEncoderPipeline(private val outputSurface: android.view.Surface) {
    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var programId = 0
    private var textureId = 0
    private var aPositionLoc = 0
    private var aTexCoordLoc = 0
    private val positionBuffer: java.nio.FloatBuffer
    private val texCoordBuffer: java.nio.FloatBuffer

    init {
        val positions = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val texCoords = floatArrayOf(0f, 1f, 1f, 1f, 0f, 0f, 1f, 0f)
        positionBuffer = java.nio.ByteBuffer.allocateDirect(positions.size * 4)
            .order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer().apply { put(positions); position(0) }
        texCoordBuffer = java.nio.ByteBuffer.allocateDirect(texCoords.size * 4)
            .order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer().apply { put(texCoords); position(0) }
        setupEgl()
        setupGl()
    }

    private fun setupEgl() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (eglDisplay == EGL14.EGL_NO_DISPLAY) throw RuntimeException("No EGL display")
        val version = IntArray(2)
        if (!EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) {
            throw RuntimeException("EGL init failed")
        }
        val attribList = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGLExt.EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val numConfigs = IntArray(1)
        EGL14.eglChooseConfig(eglDisplay, attribList, 0, configs, 0, 1, numConfigs, 0)
        val config = configs[0] ?: throw RuntimeException("No suitable EGL config")

        val ctxAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        eglContext = EGL14.eglCreateContext(eglDisplay, config, EGL14.EGL_NO_CONTEXT, ctxAttribs, 0)
        if (eglContext == EGL14.EGL_NO_CONTEXT) throw RuntimeException("EGL context creation failed")

        val surfaceAttribs = intArrayOf(EGL14.EGL_NONE)
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, config, outputSurface, surfaceAttribs, 0)
        if (eglSurface == EGL14.EGL_NO_SURFACE) throw RuntimeException("EGL surface creation failed")

        if (!EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)) {
            throw RuntimeException("eglMakeCurrent failed")
        }
    }

    private fun compileShader(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        return shader
    }

    private fun setupGl() {
        val vertexShader = """
            attribute vec4 aPosition;
            attribute vec2 aTexCoord;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = aPosition;
                vTexCoord = aTexCoord;
            }
        """.trimIndent()
        val fragmentShader = """
            precision mediump float;
            varying vec2 vTexCoord;
            uniform sampler2D uTexture;
            void main() {
                gl_FragColor = texture2D(uTexture, vTexCoord);
            }
        """.trimIndent()

        val vs = compileShader(GLES20.GL_VERTEX_SHADER, vertexShader)
        val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentShader)
        programId = GLES20.glCreateProgram()
        GLES20.glAttachShader(programId, vs)
        GLES20.glAttachShader(programId, fs)
        GLES20.glLinkProgram(programId)

        aPositionLoc = GLES20.glGetAttribLocation(programId, "aPosition")
        aTexCoordLoc = GLES20.glGetAttribLocation(programId, "aTexCoord")

        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        textureId = textures[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    fun drawFrame(bitmap: Bitmap, presentationTimeNs: Long) {
        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
        GLES20.glViewport(0, 0, bitmap.width, bitmap.height)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        GLES20.glUseProgram(programId)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        val uTextureLoc = GLES20.glGetUniformLocation(programId, "uTexture")
        GLES20.glUniform1i(uTextureLoc, 0)

        GLES20.glEnableVertexAttribArray(aPositionLoc)
        GLES20.glVertexAttribPointer(aPositionLoc, 2, GLES20.GL_FLOAT, false, 0, positionBuffer)
        GLES20.glEnableVertexAttribArray(aTexCoordLoc)
        GLES20.glVertexAttribPointer(aTexCoordLoc, 2, GLES20.GL_FLOAT, false, 0, texCoordBuffer)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(aPositionLoc)
        GLES20.glDisableVertexAttribArray(aTexCoordLoc)

        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, presentationTimeNs)
        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    fun release() {
        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(eglDisplay, eglSurface)
            EGL14.eglDestroyContext(eglDisplay, eglContext)
            EGL14.eglReleaseThread()
            EGL14.eglTerminate(eglDisplay)
        }
        eglDisplay = EGL14.EGL_NO_DISPLAY
        eglContext = EGL14.EGL_NO_CONTEXT
        eglSurface = EGL14.EGL_NO_SURFACE
    }
}

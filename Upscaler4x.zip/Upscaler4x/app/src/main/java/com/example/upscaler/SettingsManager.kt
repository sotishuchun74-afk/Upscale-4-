package com.example.upscaler

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

/** App-wide preferences: theme (light/dark/system) and GPU acceleration
 *  (NNAPI execution provider) for the ONNX Runtime session. */
object SettingsManager {
    private const val PREFS = "settings"
    private const val KEY_THEME = "theme_mode"
    private const val KEY_GPU = "gpu_acceleration"

    const val THEME_SYSTEM = 0
    const val THEME_LIGHT = 1
    const val THEME_DARK = 2

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getThemeMode(context: Context): Int = prefs(context).getInt(KEY_THEME, THEME_SYSTEM)

    fun setThemeMode(context: Context, mode: Int) {
        prefs(context).edit().putInt(KEY_THEME, mode).apply()
        applyThemeMode(mode)
    }

    fun applyThemeMode(mode: Int) {
        AppCompatDelegate.setDefaultNightMode(
            when (mode) {
                THEME_LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
                THEME_DARK -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }

    fun isGpuAccelerationEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_GPU, false)

    fun setGpuAccelerationEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_GPU, enabled).apply()
    }
}

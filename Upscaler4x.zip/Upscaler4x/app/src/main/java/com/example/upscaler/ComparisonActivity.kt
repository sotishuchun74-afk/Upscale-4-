package com.example.upscaler

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ScaleGestureDetector
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/**
 * Zoom Compare screen: a before/after slider between the original and the
 * upscaled video, with synchronized pinch-zoom/pan on both layers.
 *
 * Earlier versions of this screen ran the two videos as independent
 * MediaPlayer + TextureView pairs, free-running in real time. That
 * architecture could never fully avoid drift: the upscaled stream decodes
 * far more pixels than the original, so on some devices it simply can't
 * sustain real-time playback, and periodic seekTo()-based resyncing looked
 * like stutter — worse the longer/the more times playback looped. Tools
 * like CapCut/Wink don't hit this because they don't run two independent
 * playback clocks at all for a short compare clip.
 *
 * This version does the same: both sides are extracted ONCE into Bitmap
 * arrays indexed by the same timestamps, and a single wall-clock-driven
 * loop selects "frame N" from both arrays every tick. There is no second
 * decode clock to drift out of sync with the first, by construction — and
 * because both panels are now plain ImageViews (no live TextureView
 * surfaces), pinch-zoom is just an image transform, which is what CapCut's
 * compare view is doing under the hood too. Real audio plays from a
 * separate, video-less MediaPlayer on the original file.
 */
class ComparisonActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ORIGINAL_URI = "extra_original_uri"
        const val EXTRA_UPSCALED_URI = "extra_upscaled_uri"
        const val EXTRA_TITLE = "extra_title"
        private const val MIN_SCALE = 1f
        private const val MAX_SCALE = 6f
        private const val TARGET_FRAME_INTERVAL_MS = 50L // ~20fps sampling, used when memory allows
        private const val MIN_FRAME_INTERVAL_MS = 33L
        private const val MAX_FRAME_INTERVAL_MS = 250L // never sparser than this or motion reads as "lagging"
        // Old code capped at a flat 24 frames regardless of clip length. For anything
        // longer than ~1.2s that meant huge gaps between frames (e.g. a 20s clip only
        // got a new image every ~830ms) which is exactly what read as the video
        // "falling behind" — the seekbar/audio moved continuously while the image
        // visibly froze then jumped. Frame count is now derived from clip length and
        // a device memory budget instead of a fixed number, so longer clips still get
        // enough frames to look continuous.
        private const val MAX_FRAMES_HARD_CAP = 220 // extraction time ceiling (~a few sec per side)
        private const val MIN_FRAME_PIXELS = 480_000 // floor so zoomed-in detail doesn't turn to mush
        private const val MAX_FRAME_PIXELS = 3_000_000 // ceiling on memory per frame
        private const val TICK_MS = 33L
    }

    private lateinit var zoomContainer: FrameLayout
    private lateinit var beforeImage: ImageView
    private lateinit var afterImage: ImageView
    private lateinit var afterClipContainer: FrameLayout
    private lateinit var afterInner: FrameLayout
    private lateinit var dividerLine: View
    private lateinit var dividerHandle: View
    private lateinit var btnPlayPause: MaterialButton
    private lateinit var seekShared: SeekBar
    private lateinit var videoControls: View
    private lateinit var loadingRow: View

    private var originalUri: Uri? = null
    private var upscaledUri: Uri? = null

    private var isPlaying = false
    private var userIsSeeking = false
    private var framesReady = false

    // Frame cache: beforeFrames = upscaled (visible on the right / "4x" side,
    // the full-width bottom layer); afterFrames = original (visible on the
    // left / "Original" side, the clipped top layer) — same mapping the
    // divider/badges have always used.
    private var beforeFrames: Array<Bitmap?> = emptyArray()
    private var afterFrames: Array<Bitmap?> = emptyArray()
    private var durationMs: Long = 1L
    private var frameIntervalMs: Long = TARGET_FRAME_INTERVAL_MS

    private var audioPlayer: MediaPlayer? = null
    private var playheadStartElapsed: Long = 0L
    private var virtualPositionMs: Long = 0L

    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastShownIndex = -1

    private val playTicker = object : Runnable {
        override fun run() {
            if (isPlaying && !userIsSeeking) {
                val pos = (SystemClock.elapsedRealtime() - playheadStartElapsed) % durationMs
                // Don't swap bitmaps while a pinch is in progress: decoding/uploading
                // a new ~MB-sized bitmap to both ImageViews every tick competes with
                // the matrix updates driving the pinch and is what reads as "shaking"
                // during zoom. Audio and the virtual clock keep running underneath —
                // this only freezes the displayed frame for the gesture's duration,
                // and the very next tick after the gesture ends catches back up.
                if (!isTwoFingerPanning) {
                    showFrameAt(pos)
                    seekShared.progress = pos.toInt()
                }
                mainHandler.postDelayed(this, TICK_MS)
            }
        }
    }

    // --- Pinch-zoom / pan state, applied to zoomContainer so both layers move together ---
    private var scaleFactor = 1f
    private var transX = 0f
    private var transY = 0f
    private var isTwoFingerPanning = false
    private var isDraggingDivider = false
    private var lastFocusX = 0f
    private var lastFocusY = 0f
    private var hasLastFocus = false
    private lateinit var scaleGestureDetector: ScaleGestureDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comparison)

        originalUri = intent.getStringExtra(EXTRA_ORIGINAL_URI)?.let { Uri.parse(it) }
        upscaledUri = intent.getStringExtra(EXTRA_UPSCALED_URI)?.let { Uri.parse(it) }

        findViewById<TextView>(R.id.tvCompareTitle).text = intent.getStringExtra(EXTRA_TITLE) ?: ""
        findViewById<MaterialButton>(R.id.btnCloseCompare).setOnClickListener { finish() }

        zoomContainer = findViewById(R.id.zoomContainer)
        beforeImage = findViewById(R.id.beforeImage)
        afterImage = findViewById(R.id.afterImage)
        afterClipContainer = findViewById(R.id.afterClipContainer)
        afterInner = findViewById(R.id.afterInner)
        dividerLine = findViewById(R.id.dividerLine)
        dividerHandle = findViewById(R.id.dividerHandle)
        btnPlayPause = findViewById(R.id.btnPlayPause)
        seekShared = findViewById(R.id.seekShared)
        videoControls = findViewById(R.id.videoControls)
        loadingRow = findViewById(R.id.loadingRow)

        videoControls.visibility = View.GONE
        setupZoomAndDividerGestures()
        setupControls()

        zoomContainer.viewTreeObserver.addOnGlobalLayoutListener(object :
            android.view.ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                if (zoomContainer.width > 0) {
                    zoomContainer.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    // afterInner must always be the FULL container width — it's the
                    // clip on afterClipContainer's own width that reveals only part of
                    // it, not a resize of the upscaled image itself.
                    afterInner.layoutParams = afterInner.layoutParams.apply { width = zoomContainer.width }
                    afterClipContainer.layoutParams = afterClipContainer.layoutParams.apply {
                        width = zoomContainer.width / 2
                    }
                    dividerLine.translationX = (zoomContainer.width / 2).toFloat()
                    dividerHandle.translationX = (zoomContainer.width / 2).toFloat() - dividerHandle.layoutParams.width / 2f
                    afterInner.requestLayout()
                    afterClipContainer.requestLayout()
                }
            }
        })

        extractFrames()
    }

    // ------------------------------------------------------------- extraction

    private fun extractFrames() {
        val origUri = originalUri
        val upUri = upscaledUri
        if (origUri == null || upUri == null) {
            Toast.makeText(this, "Video manzillari topilmadi", Toast.LENGTH_LONG).show()
            return
        }
        Thread {
            val origRetriever = MediaMetadataRetriever()
            val upRetriever = MediaMetadataRetriever()
            try {
                origRetriever.setDataSource(this@ComparisonActivity, origUri)
                upRetriever.setDataSource(this@ComparisonActivity, upUri)
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Videolarni o'qib bo'lmadi", Toast.LENGTH_LONG).show()
                }
                return@Thread
            }

            val origDur = origRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val upDur = upRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val durMs = minOf(origDur, upDur).coerceAtLeast(1L)

            // 1) Pick a frame count from clip length alone first (capped so
            //    extraction doesn't take forever), THEN size each bitmap to fit
            //    a memory budget — instead of the old fixed 24-frame cap that
            //    made every clip longer than ~1.2s choppy regardless of device.
            var interval = TARGET_FRAME_INTERVAL_MS
            var count = (durMs / interval).toInt().coerceAtLeast(1)
            if (count > MAX_FRAMES_HARD_CAP) {
                count = MAX_FRAMES_HARD_CAP
                interval = (durMs / count).coerceAtLeast(MIN_FRAME_INTERVAL_MS)
            }
            if (interval > MAX_FRAME_INTERVAL_MS) interval = MAX_FRAME_INTERVAL_MS

            // 2) Two arrays (before/after) of ARGB_8888 bitmaps have to fit inside a
            //    slice of the heap. Budget a fraction of maxMemory and derive the
            //    per-frame pixel cap from it; only fall back to fewer frames if even
            //    the resolution floor won't fit (keeps sync/smoothness first, detail
            //    second, since a slightly blurrier zoom beats a stuttering compare).
            val heapBudget = (Runtime.getRuntime().maxMemory() * 0.30).toLong()
            val bytesPerPixel = 4L
            var framePixelBudget = (heapBudget / (count * 2L * bytesPerPixel)).coerceAtMost(MAX_FRAME_PIXELS.toLong())
            if (framePixelBudget < MIN_FRAME_PIXELS) {
                // Not enough headroom for this many frames at floor resolution —
                // shrink the frame count instead of the resolution.
                count = (heapBudget / (MIN_FRAME_PIXELS.toLong() * 2L * bytesPerPixel)).toInt().coerceAtLeast(1)
                interval = (durMs / count).coerceAtLeast(MIN_FRAME_INTERVAL_MS)
                framePixelBudget = MIN_FRAME_PIXELS.toLong()
            }
            val framePixelCap = framePixelBudget.coerceAtLeast(MIN_FRAME_PIXELS.toLong())

            fun grab(retriever: MediaMetadataRetriever, timeUs: Long): Bitmap? {
                val raw = try {
                    retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                } catch (e: Exception) { null } ?: try {
                    retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                } catch (e: Exception) { null } ?: return null
                val pixels = raw.width.toLong() * raw.height.toLong()
                if (pixels <= framePixelCap) return raw
                val ratio = Math.sqrt(framePixelCap.toDouble() / pixels.toDouble())
                val scaled = Bitmap.createScaledBitmap(
                    raw, (raw.width * ratio).toInt().coerceAtLeast(1),
                    (raw.height * ratio).toInt().coerceAtLeast(1), true
                )
                if (scaled !== raw) raw.recycle()
                return scaled
            }

            val before = arrayOfNulls<Bitmap>(count)
            val after = arrayOfNulls<Bitmap>(count)
            for (i in 0 until count) {
                val timeUs = (i * interval) * 1000L
                before[i] = grab(upRetriever, timeUs)
                after[i] = grab(origRetriever, timeUs)
            }
            // Forward-fill any individual extraction failures instead of ever
            // showing a blank/black frame.
            fun fill(arr: Array<Bitmap?>) {
                var last: Bitmap? = null
                for (i in arr.indices) {
                    if (arr[i] == null) arr[i] = last else last = arr[i]
                }
                if (arr[0] == null) {
                    val firstNonNull = arr.firstOrNull { it != null }
                    for (i in arr.indices) { if (arr[i] == null) arr[i] = firstNonNull }
                }
            }
            fill(before)
            fill(after)

            origRetriever.release()
            upRetriever.release()

            runOnUiThread {
                beforeFrames = before
                afterFrames = after
                durationMs = durMs
                frameIntervalMs = interval
                onFramesReady()
            }
        }.start()
    }

    private fun onFramesReady() {
        framesReady = true
        loadingRow.visibility = View.GONE
        videoControls.visibility = View.VISIBLE
        seekShared.max = durationMs.toInt()
        showFrameAt(0)
        setupAudioPlayer()
    }

    private fun showFrameAt(posMs: Long) {
        if (!framesReady || beforeFrames.isEmpty()) return
        val idx = (posMs / frameIntervalMs).toInt().coerceIn(0, beforeFrames.size - 1)
        // TICK_MS (33ms) is finer than frameIntervalMs, so most ticks land on the
        // same index as the previous one — re-decoding the same bitmap into the
        // ImageView every 33ms was pure wasted work competing with zoom/pan.
        if (idx == lastShownIndex) return
        lastShownIndex = idx
        beforeFrames[idx]?.let { beforeImage.setImageBitmap(it) }
        afterFrames[idx]?.let { afterImage.setImageBitmap(it) }
    }

    private fun setupAudioPlayer() {
        val uri = originalUri ?: return
        try {
            val player = MediaPlayer()
            player.setDataSource(this, uri)
            player.isLooping = true
            player.setOnPreparedListener { mp -> audioPlayer = mp }
            player.prepareAsync()
        } catch (e: Exception) {
            // Audio is best-effort; the visual compare still works without it.
        }
    }

    // ------------------------------------------------------------- controls

    private fun setupControls() {
        seekShared.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                virtualPositionMs = progress.toLong()
                showFrameAt(virtualPositionMs)
                if (isPlaying) playheadStartElapsed = SystemClock.elapsedRealtime() - virtualPositionMs
                try { audioPlayer?.seekTo(progress) } catch (e: Exception) { }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) { userIsSeeking = true }
            override fun onStopTrackingTouch(seekBar: SeekBar?) { userIsSeeking = false }
        })

        btnPlayPause.setOnClickListener {
            if (isPlaying) pauseBoth() else playBoth()
        }
    }

    private fun playBoth() {
        if (!framesReady) return
        playheadStartElapsed = SystemClock.elapsedRealtime() - virtualPositionMs
        try {
            audioPlayer?.seekTo(virtualPositionMs.toInt())
            audioPlayer?.start()
        } catch (e: Exception) { }
        isPlaying = true
        btnPlayPause.setIconResource(R.drawable.ic_pause)
        mainHandler.post(playTicker)
    }

    private fun pauseBoth() {
        virtualPositionMs = (SystemClock.elapsedRealtime() - playheadStartElapsed) % durationMs
        try { audioPlayer?.pause() } catch (e: Exception) { }
        isPlaying = false
        btnPlayPause.setIconResource(R.drawable.ic_play)
    }

    // ---------------------------------------------------------------- gestures

    private fun setupZoomAndDividerGestures() {
        scaleGestureDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                // Fresh gesture: don't apply a pan delta against a focus point
                // left over from a previous (possibly single-finger) touch.
                hasLastFocus = false
                // Cache the container as a GPU texture for the duration of the
                // gesture so scale/translate updates are cheap matrix ops
                // instead of re-compositing the whole subtree every touch-move.
                zoomContainer.setLayerType(View.LAYER_TYPE_HARDWARE, null)
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                zoomContainer.setLayerType(View.LAYER_TYPE_NONE, null)
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val prevScale = scaleFactor
                scaleFactor = (scaleFactor * detector.scaleFactor).coerceIn(MIN_SCALE, MAX_SCALE)
                val scaleDelta = scaleFactor - prevScale
                if (scaleDelta != 0f) {
                    // Keep the point under the two fingers visually fixed.
                    val pivotX = zoomContainer.width / 2f
                    val pivotY = zoomContainer.height / 2f
                    transX -= (detector.focusX - pivotX) * scaleDelta
                    transY -= (detector.focusY - pivotY) * scaleDelta
                }
                // Two-finger panning is driven from the detector's own focus
                // point — the single source of truth for two-finger movement.
                if (hasLastFocus) {
                    transX += detector.focusX - lastFocusX
                    transY += detector.focusY - lastFocusY
                }
                lastFocusX = detector.focusX
                lastFocusY = detector.focusY
                hasLastFocus = true
                applyZoomTransform()
                return true
            }
        })

        zoomContainer.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    isDraggingDivider = true
                    isTwoFingerPanning = false
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    isTwoFingerPanning = true
                    isDraggingDivider = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (isDraggingDivider && event.pointerCount == 1) {
                        // One finger: drag the before/after slider. Touch coordinates
                        // arrive already in zoomContainer's local (untransformed) space.
                        moveDividerTo(event.x)
                    }
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    isTwoFingerPanning = false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    isDraggingDivider = false
                    isTwoFingerPanning = false
                }
            }
            true
        }
    }

    private fun applyZoomTransform() {
        zoomContainer.scaleX = scaleFactor
        zoomContainer.scaleY = scaleFactor
        zoomContainer.translationX = transX
        zoomContainer.translationY = transY
    }

    private fun moveDividerTo(x: Float) {
        val clamped = x.coerceIn(0f, zoomContainer.width.toFloat())
        afterClipContainer.layoutParams = afterClipContainer.layoutParams.apply { width = clamped.toInt() }
        afterClipContainer.requestLayout()
        dividerLine.translationX = clamped
        dividerHandle.translationX = clamped - dividerHandle.layoutParams.width / 2f
    }

    override fun onPause() {
        super.onPause()
        if (isPlaying) pauseBoth()
    }

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacksAndMessages(null)
        audioPlayer?.release()
        audioPlayer = null
        for (b in beforeFrames) b?.recycle()
        for (b in afterFrames) b?.recycle()
    }
}

package com.example.upscaler

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import android.provider.MediaStore
import java.io.File
import java.nio.FloatBuffer

class UpscaleService : Service() {

    companion object {
        private const val CHANNEL_ID = "upscale_channel"
        private const val NOTIF_ID = 1001

        const val ACTION_PAUSE = "com.example.upscaler.ACTION_PAUSE"

        const val EXTRA_MESSAGE = "extra_message"
        const val EXTRA_JOB_ID = "extra_job_id"
        const val EXTRA_DISPLAY_NAME = "extra_display_name"
        const val EXTRA_PERCENT = "extra_percent"

        const val ACTION_PROGRESS = "com.example.upscaler.PROGRESS"
        const val ACTION_QUEUE_CHANGED = "com.example.upscaler.QUEUE_CHANGED"
        const val ACTION_DONE = "com.example.upscaler.DONE"
        const val ACTION_ERROR = "com.example.upscaler.ERROR"

        @Volatile var isRunning: Boolean = false
    }

    @Volatile private var pauseRequested = false

    private var ortEnv: OrtEnvironment? = null
    private val ortSessions = mutableMapOf<String, OrtSession>()
    private val ortInputNames = mutableMapOf<String, String>()
    private val ortStaticTileSpecs = mutableMapOf<String, Pair<Int, Int>?>()
    private var wakeLock: PowerManager.WakeLock? = null

    private val OVERLAP = 8

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_PAUSE) {
            pauseRequested = true
            return START_NOT_STICKY
        }

        if (isRunning) {
            return START_NOT_STICKY
        }

        pauseRequested = false
        createChannel()
        isRunning = true
        startForeground(NOTIF_ID, buildNotification(getString(R.string.notif_queue_starting), 0))

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Upscaler4x::QueueWakeLock")
        wakeLock?.acquire(12 * 60 * 60 * 1000L)

        Thread {
            try {
                runQueueLoop()
            } finally {
                wakeLock?.let { if (it.isHeld) it.release() }
                isRunning = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }.start()

        return START_NOT_STICKY
    }

    private fun runQueueLoop() {
        while (!pauseRequested) {
            val job = QueueManager.nextRunnable(this) ?: break
            try {
                processJob(job)
            } catch (e: Exception) {
                job.status = JobStatus.ERROR
                job.errorMessage = e.javaClass.simpleName + ": " + (e.message ?: getString(R.string.error_no_details))
                QueueManager.updateJob(this, job)
                sendBroadcast(Intent(ACTION_ERROR).apply {
                    putExtra(EXTRA_JOB_ID, job.id)
                    putExtra(EXTRA_MESSAGE, job.errorMessage)
                    setPackage(packageName)
                })
                sendBroadcast(Intent(ACTION_QUEUE_CHANGED).setPackage(packageName))
            }
        }
    }

    private fun processJob(job: Job) {
        job.status = JobStatus.PROCESSING
        QueueManager.updateJob(this, job)
        sendBroadcast(Intent(ACTION_QUEUE_CHANGED).setPackage(packageName))

        val model = ModelManager.getModel(this, job.modelId)
            ?: throw RuntimeException(getString(R.string.error_model_not_found, job.modelId))
        val session = ensureSession(model)
        val scale = model.scale
        val tileSize = model.tileSize

        val uri = Uri.parse(job.videoUri)
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(this, uri)

        if (job.frameCount == 0) {
            computeJobGeometry(job, retriever, scale)
            QueueManager.updateJob(this, job)
        }

        var audioTrackIndex = -1
        var audioFormat: MediaFormat? = null
        val probe = MediaExtractor()
        probe.setDataSource(this, uri, null)
        for (i in 0 until probe.trackCount) {
            val fmt = probe.getTrackFormat(i)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/") && audioTrackIndex == -1) {
                audioTrackIndex = i
                audioFormat = fmt
            }
        }
        probe.release()

        val frameIntervalUs = 1_000_000L / job.outFps

        var outW = job.outW
        var outH = job.outH

        val encoder = MediaCodec.createEncoderByType("video/avc")
        try {
            val caps = encoder.codecInfo.getCapabilitiesForType("video/avc").videoCapabilities
            if (!caps.isSizeSupported(outW, outH)) {
                // Step down using the encoder's real width/height alignment (usually 16px)
                // instead of a crude 5% jump, so we land on the *largest* size the encoder
                // actually supports rather than overshooting far below the chosen quality.
                val alignW = maxOf(caps.widthAlignment, 16)
                val alignH = maxOf(caps.heightAlignment, 16)
                val aspect = outW.toDouble() / outH.toDouble()

                var w = (outW / alignW) * alignW
                var found = false
                while (w >= 160) {
                    val h = ((w / aspect).toInt() / alignH) * alignH
                    if (h >= 160 && caps.isSizeSupported(w, h)) {
                        outW = w; outH = h
                        found = true
                        break
                    }
                    w -= alignW
                }
                if (!found) {
                    // Extreme fallback: clamp straight to the codec's reported max bounds.
                    val maxW = (caps.supportedWidths.upper / alignW) * alignW
                    val maxH = (caps.supportedHeights.upper / alignH) * alignH
                    outW = minOf(outW, maxW)
                    outH = minOf(outH, maxH)
                }
                job.outW = outW
                job.outH = outH
            }
        } catch (e: Exception) {
            // fall through, let configure() below report whatever it reports
        }

        val outputFormat = MediaFormat.createVideoFormat("video/avc", outW, outH).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, outW * outH * 4)
            setInteger(MediaFormat.KEY_FRAME_RATE, job.outFps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh)
            setInteger(MediaFormat.KEY_LEVEL, MediaCodecInfo.CodecProfileLevel.AVCLevel51)
        }
        try {
            encoder.configure(outputFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        } catch (e: Exception) {
            throw RuntimeException(
                getString(
                    R.string.error_encoder_unsupported, outW, outH,
                    e.javaClass.simpleName + ": " + (e.message ?: getString(R.string.error_no_details))
                )
            )
        }
        val inputSurface = encoder.createInputSurface()
        encoder.start()
        val glPipe = GlEncoderPipeline(inputSurface)

        val segmentFile = File(getExternalFilesDir(null), "job_" + job.id + "_seg_" + job.segmentPaths.size + ".mp4")
        val muxer = MediaMuxer(segmentFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxerVideoTrack = -1
        var muxerStarted = false
        val bufferInfo = MediaCodec.BufferInfo()
        var pts = 0L

        fun drainEncoder(endOfStream: Boolean) {
            if (endOfStream) encoder.signalEndOfInputStream()
            while (true) {
                val outIndex = encoder.dequeueOutputBuffer(bufferInfo, 10_000)
                when {
                    outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!endOfStream) return
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        muxerVideoTrack = muxer.addTrack(encoder.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    }
                    outIndex >= 0 -> {
                        val data = encoder.getOutputBuffer(outIndex)
                        if (data != null && bufferInfo.size > 0 && muxerStarted) {
                            data.position(bufferInfo.offset)
                            data.limit(bufferInfo.offset + bufferInfo.size)
                            muxer.writeSampleData(muxerVideoTrack, data, bufferInfo)
                        }
                        encoder.releaseOutputBuffer(outIndex, false)
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                }
            }
        }

        val sessionStart = System.currentTimeMillis()
        var framesThisSession = 0
        var pausedMidway = false

        for (frameIdx in job.nextFrameIndex until job.frameCount) {
            if (pauseRequested) {
                pausedMidway = true
                break
            }
            val timeUs = frameIdx.toLong() * frameIntervalUs
            val rawFrame = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
            if (rawFrame != null) {
                val resized = Bitmap.createScaledBitmap(rawFrame, job.procW, job.procH, true)
                var upscaled = upscaleWithTiling(resized, session, model.id, scale, tileSize)
                if (upscaled.width != outW || upscaled.height != outH) {
                    upscaled = Bitmap.createScaledBitmap(upscaled, outW, outH, true)
                }
                glPipe.drawFrame(upscaled, pts * 1000L)
                drainEncoder(false)
                pts += frameIntervalUs
            }

            framesThisSession++
            job.nextFrameIndex = frameIdx + 1

            val elapsedMs = System.currentTimeMillis() - sessionStart
            val avgMsPerFrame = elapsedMs.toDouble() / framesThisSession
            val remaining = job.frameCount - job.nextFrameIndex
            val etaMs = (avgMsPerFrame * remaining).toLong()
            val pct = (job.nextFrameIndex * 100 / job.frameCount)
            val msg = getString(
                R.string.progress_message, job.displayName, job.nextFrameIndex, job.frameCount, formatEta(etaMs)
            )
            updateNotification(msg, pct)
            sendBroadcast(Intent(ACTION_PROGRESS).apply {
                putExtra(EXTRA_JOB_ID, job.id)
                putExtra(EXTRA_MESSAGE, msg)
                putExtra(EXTRA_PERCENT, pct)
                setPackage(packageName)
            })
        }

        drainEncoder(true)
        encoder.stop()
        encoder.release()
        glPipe.release()
        inputSurface.release()
        muxer.stop()
        muxer.release()
        retriever.release()

        job.segmentPaths.add(segmentFile.absolutePath)

        if (pausedMidway) {
            job.status = JobStatus.PAUSED
            QueueManager.updateJob(this, job)
            sendBroadcast(Intent(ACTION_QUEUE_CHANGED).setPackage(packageName))
            return
        }

        updateNotification(job.displayName + ": yakunlanmoqda...", 100)
        val finalFile = finalizeJob(job, uri, audioTrackIndex, audioFormat)
        val savedUri = saveVideoToGallery(finalFile)
        finalFile.delete()

        // Job stays in the queue (status=DONE, outputUri set) instead of being removed,
        // so it keeps showing in the list and Zoom Compare can open the original vs
        // the upscaled result. The user can still remove it manually via btnRemoveJob.
        job.status = JobStatus.DONE
        job.outputUri = savedUri?.toString()
        QueueManager.updateJob(this, job)
        sendBroadcast(Intent(ACTION_DONE).apply {
            putExtra(EXTRA_JOB_ID, job.id)
            putExtra(EXTRA_DISPLAY_NAME, job.displayName)
            setPackage(packageName)
        })
        sendBroadcast(Intent(ACTION_QUEUE_CHANGED).setPackage(packageName))
    }

    private fun computeJobGeometry(job: Job, retriever: MediaMetadataRetriever, scale: Int) {
        var srcW = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            ?.toIntOrNull() ?: 0
        var srcH = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            ?.toIntOrNull() ?: 0
        val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
            ?.toIntOrNull() ?: 0
        if (rotation == 90 || rotation == 270) {
            val tmp = srcW; srcW = srcH; srcH = tmp
        }
        val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            ?.toLongOrNull() ?: 0L

        var srcFps = 24f
        val probe = MediaExtractor()
        probe.setDataSource(this, Uri.parse(job.videoUri), null)
        var videoTrackIndex = -1
        var declaredFps = -1f
        for (i in 0 until probe.trackCount) {
            val fmt = probe.getTrackFormat(i)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/") && videoTrackIndex == -1) {
                videoTrackIndex = i
                if (fmt.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                    declaredFps = fmt.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat()
                }
            }
        }

        // Container-declared KEY_FRAME_RATE is frequently wrong (many muxers store a
        // rounded/nominal value, e.g. "30" for an actual 60fps capture). Count real
        // sample timestamps instead so a genuinely high-fps source isn't silently
        // capped below the user's chosen max fps.
        if (videoTrackIndex != -1) {
            probe.selectTrack(videoTrackIndex)
            var sampleCount = 0
            var firstTimeUs = -1L
            var lastTimeUs = -1L
            while (true) {
                val t = probe.sampleTime
                if (t < 0) break
                if (firstTimeUs < 0) firstTimeUs = t
                lastTimeUs = t
                sampleCount++
                if (!probe.advance()) break
            }
            probe.unselectTrack(videoTrackIndex)
            val spanUs = lastTimeUs - firstTimeUs
            if (sampleCount > 1 && spanUs > 0) {
                val counted = (sampleCount - 1) * 1_000_000f / spanUs
                if (counted in 1f..240f) srcFps = counted
                else if (declaredFps > 0f) srcFps = declaredFps
            } else if (declaredFps > 0f) {
                srcFps = declaredFps
            }
        } else if (declaredFps > 0f) {
            srcFps = declaredFps
        }
        probe.release()

        val outFps = srcFps.coerceAtMost(job.maxFps).coerceAtLeast(1f)
        val frameIntervalUs = (1_000_000f / outFps).toLong()
        val totalDurationUs = durationMs * 1000L
        val frameCount = (totalDurationUs / frameIntervalUs).toInt() + 1

        val processCap = job.targetLongSide / scale
        val longSide = maxOf(srcW, srcH).coerceAtLeast(1)
        val downscale = if (longSide > processCap) processCap.toFloat() / longSide else 1f
        val procW = (srcW * downscale).toInt().coerceAtLeast(16)
        val procH = (srcH * downscale).toInt().coerceAtLeast(16)

        job.frameCount = frameCount
        job.procW = procW
        job.procH = procH
        job.outW = ((procW * scale) / 16) * 16
        job.outH = ((procH * scale) / 16) * 16
        job.outFps = outFps.toInt().coerceAtLeast(1)
    }

    private fun finalizeJob(
        job: Job,
        sourceUri: Uri,
        audioTrackIndex: Int,
        audioFormat: MediaFormat?
    ): File {
        val outputFile = File(getExternalFilesDir(null), "upscaled_" + job.id + ".mp4")
        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val firstExtractor = MediaExtractor()
        firstExtractor.setDataSource(job.segmentPaths[0])
        var videoFormat: MediaFormat? = null
        for (i in 0 until firstExtractor.trackCount) {
            val fmt = firstExtractor.getTrackFormat(i)
            if (fmt.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) {
                videoFormat = fmt
                break
            }
        }
        firstExtractor.release()
        if (videoFormat == null) throw RuntimeException(getString(R.string.error_segment_format_not_found))

        val videoTrackIndex = muxer.addTrack(videoFormat)
        val audioMuxTrack = if (audioFormat != null) muxer.addTrack(audioFormat) else -1
        muxer.start()

        val bufferInfo = MediaCodec.BufferInfo()
        val buffer = java.nio.ByteBuffer.allocate(2_097_152)
        var ptsOffset = 0L

        for (path in job.segmentPaths) {
            val extractor = MediaExtractor()
            extractor.setDataSource(path)
            var videoTrack = -1
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                if (fmt.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) {
                    videoTrack = i
                    break
                }
            }
            if (videoTrack == -1) { extractor.release(); continue }
            extractor.selectTrack(videoTrack)

            var maxPts = 0L
            while (true) {
                buffer.clear()
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                bufferInfo.offset = 0
                bufferInfo.size = size
                bufferInfo.presentationTimeUs = extractor.sampleTime + ptsOffset
                bufferInfo.flags = extractor.sampleFlags
                muxer.writeSampleData(videoTrackIndex, buffer, bufferInfo)
                maxPts = maxOf(maxPts, extractor.sampleTime)
                extractor.advance()
            }
            ptsOffset += maxPts + 1
            extractor.release()
            File(path).delete()
        }

        if (audioTrackIndex != -1 && audioMuxTrack != -1) {
            val audioExtractor = MediaExtractor()
            audioExtractor.setDataSource(this, sourceUri, null)
            audioExtractor.selectTrack(audioTrackIndex)
            val abuf = java.nio.ByteBuffer.allocate(1_048_576)
            val ainfo = MediaCodec.BufferInfo()
            while (true) {
                val size = audioExtractor.readSampleData(abuf, 0)
                if (size < 0) break
                if (audioExtractor.sampleTime > ptsOffset) break
                ainfo.offset = 0
                ainfo.size = size
                ainfo.presentationTimeUs = audioExtractor.sampleTime
                ainfo.flags = audioExtractor.sampleFlags
                muxer.writeSampleData(audioMuxTrack, abuf, ainfo)
                audioExtractor.advance()
            }
            audioExtractor.release()
        }

        muxer.stop()
        muxer.release()
        return outputFile
    }

    private fun formatEta(ms: Long): String {
        val totalSec = ms / 1000
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return when {
            h > 0 -> getString(R.string.eta_hours_min, h.toInt(), m.toInt())
            m > 0 -> getString(R.string.eta_min_sec, m.toInt(), s.toInt())
            else -> getString(R.string.eta_sec, s.toInt())
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW
            )
            mgr.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String, progress: Int): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setProgress(100, progress, progress == 0)
            .build()
    }

    private fun updateNotification(text: String, progress: Int) {
        val mgr = getSystemService(NotificationManager::class.java)
        mgr.notify(NOTIF_ID, buildNotification(text, progress))
    }

    private fun ensureSession(model: UpscaleModel): OrtSession {
        ortSessions[model.id]?.let { return it }
        val env = ortEnv ?: OrtEnvironment.getEnvironment().also { ortEnv = it }
        val bytes = ModelManager.loadBytes(this, model)

        // GridSample-based models (e.g. DySample upsampling) are known to not always
        // fully delegate to NNAPI on every device, which can silently degrade output
        // quality rather than throw. Warn rather than fail outright.
        val hasGridSample = try {
            String(bytes, Charsets.ISO_8859_1).contains("GridSample")
        } catch (e: Exception) { false }
        if (hasGridSample && SettingsManager.isGpuAccelerationEnabled(this)) {
            updateNotification(
                getString(R.string.gridsample_gpu_warning, model.name),
                0
            )
        }

        val options = OrtSession.SessionOptions()
        if (SettingsManager.isGpuAccelerationEnabled(this)) {
            try {
                // NNAPI hands the graph to the device's GPU/DSP/NPU driver when available.
                // If the device or model isn't compatible this throws, so we fall back to CPU
                // silently rather than failing the whole job.
                options.addNnapi()
            } catch (e: Exception) {
                // fall back to CPU execution provider
            }
        }
        val session = env.createSession(bytes, options)
        ortSessions[model.id] = session

        // Bug fix (Muammo A): don't hardcode the input tensor name — custom/imported
        // models (e.g. PyTorch->ONNX exports) rarely name it "input" (it's often
        // something like "onnx::Conv_0"). Read the real name once and cache it.
        ortInputNames[model.id] = session.inputNames.firstOrNull() ?: "input"

        // Bug fix (Muammo B): some fully-optimized exports have a completely static
        // input/output shape (no dynamic axes), e.g. input [1,3,256,256] -> output
        // [1,3,1024,1024]. Detect that here so upscaleWithTiling can pad any
        // undersized (edge) tile up to this exact size before running inference.
        ortStaticTileSpecs[model.id] = try {
            val info = session.inputInfo[ortInputNames[model.id]]?.info as? ai.onnxruntime.TensorInfo
            val shape = info?.shape
            // NCHW: index 2 = height, index 3 = width. A dimension is "static" when
            // ONNX Runtime reports a concrete positive value (dynamic axes report -1).
            if (shape != null && shape.size == 4 && shape[2] > 0 && shape[3] > 0) {
                Pair(shape[3].toInt(), shape[2].toInt()) // (width, height)
            } else null
        } catch (e: Exception) {
            null
        }

        return session
    }

    private fun saveVideoToGallery(file: File): Uri? {
        val resolver = contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Upscaler4x")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
        val itemUri = resolver.insert(collection, values) ?: return null
        resolver.openOutputStream(itemUri)?.use { out ->
            file.inputStream().use { input -> input.copyTo(out) }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(itemUri, values, null, null)
        } else {
            sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, itemUri))
        }
        return itemUri
    }

    private fun upscaleWithTiling(input: Bitmap, session: OrtSession, modelId: String, scale: Int, tileSize: Int): Bitmap {
        val w = input.width
        val h = input.height
        val outBitmap = Bitmap.createBitmap(w * scale, h * scale, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outBitmap)
        val staticSpec = ortStaticTileSpecs[modelId] // (netW, netH) or null when the model has dynamic axes

        // A fully static-shape model needs EVERY tile fed to it to be exactly
        // netW x netH — including interior tiles, not just the short ones at the
        // image edge. The OVERLAP context margin (added on top of tileSize) would
        // push interior tiles past that fixed size just as much as a short edge
        // tile falls under it, so for static models we step by the model's own
        // net size and drop the overlap entirely; only the edge-padding fix below
        // (replicate-pad up to netW x netH) still applies, and now handles both
        // "too small" cases uniformly instead of leaving interior tiles mismatched.
        val effectiveTileSize = staticSpec?.first ?: tileSize
        val effectiveOverlap = if (staticSpec != null) 0 else OVERLAP

        var y = 0
        while (y < h) {
            val tileH = minOf(effectiveTileSize, h - y)
            var x = 0
            while (x < w) {
                val tileW = minOf(effectiveTileSize, w - x)

                val padLeft = minOf(effectiveOverlap, x)
                val padTop = minOf(effectiveOverlap, y)
                val padRight = minOf(effectiveOverlap, w - (x + tileW))
                val padBottom = minOf(effectiveOverlap, h - (y + tileH))

                val cropX = x - padLeft
                val cropY = y - padTop
                val cropW = tileW + padLeft + padRight
                val cropH = tileH + padTop + padBottom

                var tileBitmap = Bitmap.createBitmap(input, cropX, cropY, cropW, cropH)

                // Bug fix (Muammo B): tiles at the right/bottom edge of the frame are
                // often smaller than tileSize (image dimensions rarely divide evenly).
                // A model with a fully static input shape (no dynamic axes) only accepts
                // exactly netW x netH, so pad the shortfall by replicating the edge
                // pixels, run inference on the full-size tile, then crop the padded
                // area back off the result below.
                var padExtraRight = 0
                var padExtraBottom = 0
                if (staticSpec != null) {
                    val (netW, netH) = staticSpec
                    padExtraRight = maxOf(0, netW - cropW)
                    padExtraBottom = maxOf(0, netH - cropH)
                    if (padExtraRight > 0 || padExtraBottom > 0) {
                        tileBitmap = padEdgeReplicate(tileBitmap, padExtraRight, padExtraBottom)
                    }
                }

                val outTile = runModelOnTile(tileBitmap, session)

                val srcLeft = padLeft * scale
                val srcTop = padTop * scale
                val srcW = tileW * scale
                val srcH = tileH * scale
                // Guard against the output tensor being smaller than expected (e.g. a
                // static-output model) so createBitmap never receives an out-of-range crop.
                val safeW = minOf(srcW, outTile.width - srcLeft)
                val safeH = minOf(srcH, outTile.height - srcTop)
                val finalTile = Bitmap.createBitmap(outTile, srcLeft, srcTop, safeW, safeH)

                canvas.drawBitmap(finalTile, (x * scale).toFloat(), (y * scale).toFloat(), null)

                x += tileW
            }
            y += tileH
        }
        return outBitmap
    }

    /** Pads a bitmap on the right/bottom by replicating its edge pixels, so a tile
     *  smaller than a model's static input shape can still be fed to it. */
    private fun padEdgeReplicate(bitmap: Bitmap, padRight: Int, padBottom: Int): Bitmap {
        if (padRight <= 0 && padBottom <= 0) return bitmap
        val w = bitmap.width
        val h = bitmap.height
        val padded = Bitmap.createBitmap(w + padRight, h + padBottom, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(padded)
        canvas.drawBitmap(bitmap, 0f, 0f, null)
        if (padRight > 0) {
            val rightEdge = Bitmap.createBitmap(bitmap, w - 1, 0, 1, h)
            val stretched = Bitmap.createScaledBitmap(rightEdge, padRight, h, false)
            canvas.drawBitmap(stretched, w.toFloat(), 0f, null)
        }
        if (padBottom > 0) {
            val bottomEdge = Bitmap.createBitmap(padded, 0, h - 1, padded.width, 1)
            val stretched = Bitmap.createScaledBitmap(bottomEdge, padded.width, padBottom, false)
            canvas.drawBitmap(stretched, 0f, h.toFloat(), null)
        }
        return padded
    }

    private fun runModelOnTile(bitmap: Bitmap, session: OrtSession): Bitmap {
        val env = ortEnv!!
        val inputTensor = bitmapToTensor(bitmap, env)
        inputTensor.use { tensor ->
            // Bug fix (Muammo A): use the model's real input name instead of a
            // hardcoded "input" — custom exports commonly name it something else
            // (e.g. "onnx::Conv_0"), which used to throw an OrtException and fail the job.
            val inputName = session.inputNames.firstOrNull() ?: "input"
            val inputs = mapOf(inputName to tensor)
            session.run(inputs).use { result ->
                val outputTensor = result[0] as OnnxTensor
                return tensorToBitmap(outputTensor)
            }
        }
    }

    private fun bitmapToTensor(bitmap: Bitmap, env: OrtEnvironment): OnnxTensor {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val floatBuffer = FloatBuffer.allocate(3 * w * h)
        val rArr = FloatArray(w * h)
        val gArr = FloatArray(w * h)
        val bArr = FloatArray(w * h)
        for (i in 0 until w * h) {
            val p = pixels[i]
            rArr[i] = ((p shr 16) and 0xFF) / 255f
            gArr[i] = ((p shr 8) and 0xFF) / 255f
            bArr[i] = (p and 0xFF) / 255f
        }
        floatBuffer.put(rArr)
        floatBuffer.put(gArr)
        floatBuffer.put(bArr)
        floatBuffer.rewind()

        val shape = longArrayOf(1, 3, h.toLong(), w.toLong())
        return OnnxTensor.createTensor(env, floatBuffer, shape)
    }

    private fun tensorToBitmap(tensor: OnnxTensor): Bitmap {
        val shape = tensor.info.shape
        val h = shape[2].toInt()
        val w = shape[3].toInt()
        val size = h * w

        val buffer = tensor.floatBuffer
        val rArr = FloatArray(size)
        val gArr = FloatArray(size)
        val bArr = FloatArray(size)
        buffer.get(rArr)
        buffer.get(gArr)
        buffer.get(bArr)

        val pixels = IntArray(size)
        for (i in 0 until size) {
            val r = (rArr[i].coerceIn(0f, 1f) * 255).toInt()
            val g = (gArr[i].coerceIn(0f, 1f) * 255).toInt()
            val b = (bArr[i].coerceIn(0f, 1f) * 255).toInt()
            pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }

        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, w, 0, 0, w, h)
        return bmp
    }

    override fun onDestroy() {
        super.onDestroy()
        ortSessions.values.forEach { it.close() }
        ortSessions.clear()
        ortInputNames.clear()
        ortStaticTileSpecs.clear()
        ortEnv?.close()
        wakeLock?.let { if (it.isHeld) it.release() }
    }
}

class GlEncoderPipeline(private val outputSurface: android.view.Surface) {
    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var programId = 0
    private var textureId = 0
    private var aPositionLoc = 0
    private var aTexCoordLoc = 0
    private val positionBuffer: java.nio.FloatBuffer
    private val texCoordBuffer: java.nio.FloatBuffer

    init {
        val positions = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val texCoords = floatArrayOf(0f, 1f, 1f, 1f, 0f, 0f, 1f, 0f)
        positionBuffer = java.nio.ByteBuffer.allocateDirect(positions.size * 4)
            .order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer().apply { put(positions); position(0) }
        texCoordBuffer = java.nio.ByteBuffer.allocateDirect(texCoords.size * 4)
            .order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer().apply { put(texCoords); position(0) }
        setupEgl()
        setupGl()
    }

    private fun setupEgl() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (eglDisplay == EGL14.EGL_NO_DISPLAY) throw RuntimeException("No EGL display")
        val version = IntArray(2)
        if (!EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) {
            throw RuntimeException("EGL init failed")
        }
        val attribList = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGLExt.EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val numConfigs = IntArray(1)
        EGL14.eglChooseConfig(eglDisplay, attribList, 0, configs, 0, 1, numConfigs, 0)
        val config = configs[0] ?: throw RuntimeException("No suitable EGL config")

        val ctxAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        eglContext = EGL14.eglCreateContext(eglDisplay, config, EGL14.EGL_NO_CONTEXT, ctxAttribs, 0)
        if (eglContext == EGL14.EGL_NO_CONTEXT) throw RuntimeException("EGL context creation failed")

        val surfaceAttribs = intArrayOf(EGL14.EGL_NONE)
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, config, outputSurface, surfaceAttribs, 0)
        if (eglSurface == EGL14.EGL_NO_SURFACE) throw RuntimeException("EGL surface creation failed")

        if (!EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)) {
            throw RuntimeException("eglMakeCurrent failed")
        }
    }

    private fun compileShader(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        return shader
    }

    private fun setupGl() {
        val vertexShader = "attribute vec4 aPosition;\n" +
            "attribute vec2 aTexCoord;\n" +
            "varying vec2 vTexCoord;\n" +
            "void main() {\n" +
            "    gl_Position = aPosition;\n" +
            "    vTexCoord = aTexCoord;\n" +
            "}\n"
        val fragmentShader = "precision mediump float;\n" +
            "varying vec2 vTexCoord;\n" +
            "uniform sampler2D uTexture;\n" +
            "void main() {\n" +
            "    gl_FragColor = texture2D(uTexture, vTexCoord);\n" +
            "}\n"

        val vs = compileShader(GLES20.GL_VERTEX_SHADER, vertexShader)
        val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentShader)
        programId = GLES20.glCreateProgram()
        GLES20.glAttachShader(programId, vs)
        GLES20.glAttachShader(programId, fs)
        GLES20.glLinkProgram(programId)

        aPositionLoc = GLES20.glGetAttribLocation(programId, "aPosition")
        aTexCoordLoc = GLES20.glGetAttribLocation(programId, "aTexCoord")

        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        textureId = textures[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    fun drawFrame(bitmap: Bitmap, presentationTimeNs: Long) {
        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
        GLES20.glViewport(0, 0, bitmap.width, bitmap.height)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        GLES20.glUseProgram(programId)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        val uTextureLoc = GLES20.glGetUniformLocation(programId, "uTexture")
        GLES20.glUniform1i(uTextureLoc, 0)

        GLES20.glEnableVertexAttribArray(aPositionLoc)
        GLES20.glVertexAttribPointer(aPositionLoc, 2, GLES20.GL_FLOAT, false, 0, positionBuffer)
        GLES20.glEnableVertexAttribArray(aTexCoordLoc)
        GLES20.glVertexAttribPointer(aTexCoordLoc, 2, GLES20.GL_FLOAT, false, 0, texCoordBuffer)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(aPositionLoc)
        GLES20.glDisableVertexAttribArray(aTexCoordLoc)

        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, presentationTimeNs)
        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    fun release() {
        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(eglDisplay, eglSurface)
            EGL14.eglDestroyContext(eglDisplay, eglContext)
            EGL14.eglReleaseThread()
            EGL14.eglTerminate(eglDisplay)
        }
        eglDisplay = EGL14.EGL_NO_DISPLAY
        eglContext = EGL14.EGL_NO_CONTEXT
        eglSurface = EGL14.EGL_NO_SURFACE
    }
}

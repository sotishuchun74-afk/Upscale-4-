package com.example.upscaler

import android.os.Bundle
import android.widget.TextView

class HistoryActivity : BaseNavActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_placeholder)
        findViewById<TextView>(R.id.tvPlaceholderTitle).setText(R.string.history_title)
        findViewById<TextView>(R.id.tvPlaceholderBody).setText(R.string.history_empty)
        setupBottomNav(R.id.nav_history)
    }
}

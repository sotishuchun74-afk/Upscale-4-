package com.example.upscaler

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : BaseNavActivity() {

    private lateinit var radioGroupTheme: RadioGroup
    private lateinit var switchGpu: Switch
    private lateinit var listModelsContainer: LinearLayout

    private var pickedModelUri: Uri? = null
    private var pickedFileText: TextView? = null

    private var pickedTileEdit: EditText? = null

    private val pickOnnxLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                pickedModelUri = uri
                try {
                    contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) { /* provider may not support it; proceed anyway */ }
                pickedFileText?.text = uri.lastPathSegment ?: uri.toString()
                detectAndPrefillStaticTileSize(uri)
            }
        }

    /** Bonus (Muammo B): if the picked .onnx has a fully static input shape (no
     *  dynamic axes), briefly open it to read that width and prefill the tile-size
     *  field, so the user doesn't have to guess a value that matches the model. */
    private fun detectAndPrefillStaticTileSize(uri: Uri) {
        val tileEdit = pickedTileEdit ?: return
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@Thread
                val env = ai.onnxruntime.OrtEnvironment.getEnvironment()
                env.createSession(bytes).use { session ->
                    val inputName = session.inputNames.firstOrNull() ?: return@use
                    val info = session.inputInfo[inputName]?.info as? ai.onnxruntime.TensorInfo
                    val shape = info?.shape
                    if (shape != null && shape.size == 4 && shape[2] > 0 && shape[3] > 0 && shape[2] == shape[3]) {
                        val netSize = shape[2].toInt()
                        runOnUiThread {
                            tileEdit.setText(netSize.toString())
                            Toast.makeText(
                                this, getString(R.string.toast_tile_autodetected, netSize),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            } catch (e: Exception) {
                // Not readable as ONNX yet, or shape isn't static — leave the
                // user's manually-entered value untouched.
            }
        }.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        setupBottomNav(R.id.nav_home)

        radioGroupTheme = findViewById(R.id.radioGroupTheme)
        switchGpu = findViewById(R.id.switchGpuAcceleration)
        listModelsContainer = findViewById(R.id.listModelsContainer)
        val btnAddModel: Button = findViewById(R.id.btnAddModelSettings)
        val radioGroupLanguage: RadioGroup = findViewById(R.id.radioGroupLanguage)

        val currentTag = androidx.appcompat.app.AppCompatDelegate.getApplicationLocales().get(0)?.language
        when (currentTag) {
            "uz" -> radioGroupLanguage.check(R.id.radioLangUz)
            "ru" -> radioGroupLanguage.check(R.id.radioLangRu)
            else -> radioGroupLanguage.check(R.id.radioLangEn)
        }
        radioGroupLanguage.setOnCheckedChangeListener { _, checkedId ->
            val tag = when (checkedId) {
                R.id.radioLangUz -> "uz"
                R.id.radioLangRu -> "ru"
                else -> "en"
            }
            androidx.appcompat.app.AppCompatDelegate.setApplicationLocales(
                androidx.core.os.LocaleListCompat.forLanguageTags(tag)
            )
        }

        when (SettingsManager.getThemeMode(this)) {
            SettingsManager.THEME_LIGHT -> radioGroupTheme.check(R.id.radioThemeLight)
            SettingsManager.THEME_DARK -> radioGroupTheme.check(R.id.radioThemeDark)
            else -> radioGroupTheme.check(R.id.radioThemeSystem)
        }
        radioGroupTheme.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.radioThemeLight -> SettingsManager.THEME_LIGHT
                R.id.radioThemeDark -> SettingsManager.THEME_DARK
                else -> SettingsManager.THEME_SYSTEM
            }
            SettingsManager.setThemeMode(this, mode)
        }

        switchGpu.isChecked = SettingsManager.isGpuAccelerationEnabled(this)
        switchGpu.setOnCheckedChangeListener { _, isChecked ->
            SettingsManager.setGpuAccelerationEnabled(this, isChecked)
        }

        refreshModels()

        btnAddModel.setOnClickListener { showAddModelDialog() }
    }

    private fun refreshModels() {
        listModelsContainer.removeAllViews()
        for (model in ModelManager.getModels(this)) {
            val view = LayoutInflater.from(this).inflate(R.layout.item_model, listModelsContainer, false)
            val tvInfo = view.findViewById<TextView>(R.id.tvModelInfo)
            val btnRemove = view.findViewById<Button>(R.id.btnRemoveModel)

            tvInfo.text = model.name + "  (scale=" + model.scale + ", tile=" + model.tileSize + ")" +
                if (model.isBuiltIn) " \u2605" else ""

            if (model.isBuiltIn) {
                btnRemove.isEnabled = false
                btnRemove.alpha = 0.4f
                btnRemove.setOnClickListener {
                    Toast.makeText(this, R.string.remove_model_builtin_blocked, Toast.LENGTH_SHORT).show()
                }
            } else {
                btnRemove.isEnabled = true
                btnRemove.alpha = 1f
                btnRemove.setOnClickListener {
                    ModelManager.removeModel(this, model.id)
                    refreshModels()
                }
            }
            listModelsContainer.addView(view)
        }
    }

    private fun showAddModelDialog() {
        pickedModelUri = null
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_model, null)
        val btnPick: Button = view.findViewById(R.id.btnPickOnnxFile)
        val tvPicked: TextView = view.findViewById(R.id.tvPickedFile)
        val etName: EditText = view.findViewById(R.id.etModelName)
        val etScale: EditText = view.findViewById(R.id.etModelScale)
        val etTile: EditText = view.findViewById(R.id.etModelTile)
        pickedFileText = tvPicked
        pickedTileEdit = etTile

        btnPick.setOnClickListener { pickOnnxLauncher.launch(arrayOf("*/*")) }

        AlertDialog.Builder(this)
            .setTitle(R.string.add_model_title)
            .setView(view)
            .setPositiveButton(R.string.add_model_save) { _, _ ->
                val uri = pickedModelUri
                if (uri == null) {
                    Toast.makeText(this, R.string.model_pick_file_first, Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val scale = etScale.text.toString().toIntOrNull()
                val tile = etTile.text.toString().toIntOrNull()
                if (scale == null || tile == null) {
                    Toast.makeText(this, R.string.model_invalid_values, Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val name = etName.text.toString().ifBlank { uri.lastPathSegment ?: "Custom model" }
                try {
                    ModelManager.importModel(this, uri, name, scale, tile)
                    refreshModels()
                    Toast.makeText(this, R.string.model_added, Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, e.message ?: getString(R.string.toast_generic_error), Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton(R.string.add_model_cancel, null)
            .show()
    }

}

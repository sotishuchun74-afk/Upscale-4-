# 4x Upscaler — faqat GitHub orqali APK yasash

Bu loyiha `4x-HFA2kLUDVAESwinIR-light.onnx` modelini ishlatib, rasmni 4 barobar
kattalashtiruvchi Android ilova. Kompyuter yoki Android Studio kerak emas —
GitHub Actions APK'ni sizning o'rningizga buluk (cloud) muhitda build qiladi.

## 1-qadam: GitHub'da repo yaratish

1. github.com'ga kiring, o'ng yuqoridagi **"+"** tugmasi → **"New repository"**
2. Nom bering (masalan `upscaler-app`), **Public** yoki **Private** — farqi yo'q
3. **"Create repository"** tugmasini bosing (boshqa hech narsani belgilamang)

## 2-qadam: Fayllarni yuklash

1. Yangi ochilgan repo sahifasida **"uploading an existing file"** havolasini bosing
   (yoki **Add file → Upload files**)
2. Kompyuteringizda ushbu papkaning **ichidagi barcha fayl va papkalarni**
   (shu jumladan yashirin `.github` papkasini) tanlab, brauzerga
   sudrab tashlang (drag & drop)
   - Muhim: `.github` papkasi ba'zi fayl menejerlarida yashirin bo'lishi mumkin —
     "yashirin fayllarni ko'rsatish" sozlamasini yoqing
3. Pastda **"Commit changes"** tugmasini bosing

> Agar drag & drop butun papka tuzilishini saqlamasa, GitHub'ning **"github.dev"**
> veb-muharriridan foydalanib fayllarni qo'lda yaratishingiz ham mumkin —
> aytsangiz, shu usulda ham yordam beraman.

## 3-qadam: Build jarayonini kuzatish

1. Repo sahifasida yuqoridagi **"Actions"** bo'limiga o'ting
2. "Build APK" ishi avtomatik boshlanadi (fayllar yuklangandan keyin) —
   sariq nuqta = ishlayapti, yashil belgi = tugadi (odatda 3-6 daqiqa)
3. Agar avtomatik boshlanmasa: Actions → **"Build APK"** → **"Run workflow"**

## 4-qadam: APK'ni yuklab olish

1. Tugagan (yashil) build ustiga bosing
2. Pastda **"Artifacts"** qismida **"upscaler-apk"** deb yozilgan faylni bosib yuklab oling
   (bu `.zip` bo'lib keladi, ichida `app-debug.apk` bor)
3. Zip'ni oching, `app-debug.apk` faylini telefoningizga o'tkazing
   (Google Drive, Telegram "Saved Messages" va h.k. orqali)
4. Telefonda faylni oching → "Noma'lum manbalar"ga ruxsat bering → o'rnating

## Eslatmalar

- Model biroz og'ir (transformator arxitekturasi), shuning uchun ilova rasmni
  kichik bo'laklarga (96x96) bo'lib qayta ishlaydi — katta rasmlar uchun bu
  bir necha daqiqa vaqt olishi mumkin.
- Eng yaxshi natija uchun avval kichikroq (masalan 300–500 piksel) rasmlar bilan
  sinab ko'ring.
- Agar build xatolik bersa, Actions loglarini menga tashlang — sababi va
  yechimini topib beraman.

package com.example.upscaler

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.ScaleGestureDetector
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.android.material.button.MaterialButton
import kotlin.math.abs

/**
 * Zoom Compare screen: a before/after slider between the original and the
 * upscaled video, with synchronized pinch-zoom/pan on both layers.
 *
 * History of this screen, for whoever touches it next:
 *  1) Two independent MediaPlayer + TextureView pairs, free-running in real
 *     time. Never stayed in sync: the upscaled stream decodes far more
 *     pixels than the original, so it can lag, and periodic seekTo()
 *     resyncing looked like a stutter/jump.
 *  2) Both sides pre-extracted into Bitmap arrays via MediaMetadataRetriever
 *     and played back as a wall-clock-driven slideshow. This removed drift
 *     by construction (same array index = same instant on both sides) but
 *     was fundamentally the wrong tool: extraction was slow, capped frame
 *     counts made anything but very short clips choppy, and it was never
 *     real video playback to begin with.
 *
 * This version goes back to real video decode (two ExoPlayer instances,
 * TextureView-backed so the existing pinch-zoom/pan transform code keeps
 * working unmodified) but fixes what (1) got wrong: the two players are not
 * left to free-run independently. The ORIGINAL is the master clock (it also
 * carries the audio). The UPSCALED player is muted and is continuously
 * nudged to match the master's position:
 *   - small drift (< SOFT_SYNC_THRESHOLD_MS)  -> ignored, imperceptible
 *   - moderate drift                          -> corrected with a tiny
 *                                                playback-speed nudge
 *                                                (0.97x-1.03x), which is
 *                                                inaudible/invisible and
 *                                                converges in ~1-2s
 *   - large drift (stall, seek, loop restart) -> hard seekTo() snap, which
 *                                                is rare so it doesn't read
 *                                                as stutter
 * This is the same master-clock + speed-nudge technique dual-video-sync
 * tools use; it avoids both failure modes above because it's decoding real
 * video (no slideshow) while actively correcting drift (no free-running).
 */
class ComparisonActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ORIGINAL_URI = "extra_original_uri"
        const val EXTRA_UPSCALED_URI = "extra_upscaled_uri"
        const val EXTRA_TITLE = "extra_title"
        private const val MIN_SCALE = 1f
        private const val MAX_SCALE = 6f

        private const val SYNC_CHECK_INTERVAL_MS = 300L
        private const val SOFT_SYNC_THRESHOLD_MS = 60L   // below this: do nothing, imperceptible
        private const val HARD_SYNC_THRESHOLD_MS = 350L  // above this: snap instead of nudging
        private const val NUDGE_SPEED_DELTA = 0.03f      // +-3% playback speed while correcting
        private const val SEEKBAR_TICK_MS = 200L
    }

    private lateinit var zoomContainer: FrameLayout
    private lateinit var beforePlayerView: PlayerView
    private lateinit var afterPlayerView: PlayerView
    private lateinit var afterClipContainer: FrameLayout
    private lateinit var afterInner: FrameLayout
    private lateinit var dividerLine: View
    private lateinit var dividerHandle: View
    private lateinit var btnPlayPause: MaterialButton
    private lateinit var seekShared: SeekBar
    private lateinit var videoControls: View
    private lateinit var loadingRow: View

    private var originalUri: Uri? = null
    private var upscaledUri: Uri? = null

    // masterPlayer = original (has audio, drives the shared clock/seekbar).
    // slavePlayer  = upscaled (muted, kept in lockstep with masterPlayer).
    // Naming below (before=upscaled bottom layer, after=original clipped top
    // layer) matches the divider/badge mapping this screen has always used.
    private var masterPlayer: ExoPlayer? = null
    private var slavePlayer: ExoPlayer? = null

    private var isPlaying = false
    private var userIsSeeking = false
    private var masterReady = false
    private var slaveReady = false
    private var isSlaveNudged = false

    private val mainHandler = Handler(Looper.getMainLooper())

    private val seekTicker = object : Runnable {
        override fun run() {
            if (isPlaying && !userIsSeeking) {
                masterPlayer?.let { seekShared.progress = it.currentPosition.toInt() }
            }
            mainHandler.postDelayed(this, SEEKBAR_TICK_MS)
        }
    }

    // Keeps the upscaled player locked to the original player's position.
    // Runs continuously (cheap: two Long reads + maybe a speed change), even
    // during pinch-zoom, since it does no bitmap/layout work.
    private val syncTicker = object : Runnable {
        override fun run() {
            val master = masterPlayer
            val slave = slavePlayer
            if (master != null && slave != null && isPlaying && !userIsSeeking) {
                val drift = master.currentPosition - slave.currentPosition
                when {
                    abs(drift) > HARD_SYNC_THRESHOLD_MS -> {
                        // Rare: e.g. one side looped back to 0 slightly before
                        // the other, or a decoder stall. Snap instead of
                        // trying to nudge out of a huge gap gradually.
                        slave.seekTo(master.currentPosition)
                        if (isSlaveNudged) {
                            slave.setPlaybackParameters(PlaybackParameters(1f))
                            isSlaveNudged = false
                        }
                    }
                    abs(drift) > SOFT_SYNC_THRESHOLD_MS -> {
                        // Speed the slave up if it's behind, slow it down if
                        // it's ahead. Inaudible (muted) and visually
                        // imperceptible at 3%, converges well before the
                        // next hard-drift threshold would trigger.
                        val speed = if (drift > 0) 1f + NUDGE_SPEED_DELTA else 1f - NUDGE_SPEED_DELTA
                        slave.setPlaybackParameters(PlaybackParameters(speed))
                        isSlaveNudged = true
                    }
                    isSlaveNudged -> {
                        slave.setPlaybackParameters(PlaybackParameters(1f))
                        isSlaveNudged = false
                    }
                }
            }
            mainHandler.postDelayed(this, SYNC_CHECK_INTERVAL_MS)
        }
    }

    // --- Pinch-zoom / pan state, applied to zoomContainer so both layers move together ---
    private var scaleFactor = 1f
    private var transX = 0f
    private var transY = 0f
    private var isTwoFingerPanning = false
    private var isDraggingDivider = false
    private var lastFocusX = 0f
    private var lastFocusY = 0f
    private var hasLastFocus = false
    private lateinit var scaleGestureDetector: ScaleGestureDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comparison)

        originalUri = intent.getStringExtra(EXTRA_ORIGINAL_URI)?.let { Uri.parse(it) }
        upscaledUri = intent.getStringExtra(EXTRA_UPSCALED_URI)?.let { Uri.parse(it) }

        findViewById<TextView>(R.id.tvCompareTitle).text = intent.getStringExtra(EXTRA_TITLE) ?: ""
        findViewById<MaterialButton>(R.id.btnCloseCompare).setOnClickListener { finish() }

        zoomContainer = findViewById(R.id.zoomContainer)
        beforePlayerView = findViewById(R.id.beforePlayerView)
        afterPlayerView = findViewById(R.id.afterPlayerView)
        afterClipContainer = findViewById(R.id.afterClipContainer)
        afterInner = findViewById(R.id.afterInner)
        dividerLine = findViewById(R.id.dividerLine)
        dividerHandle = findViewById(R.id.dividerHandle)
        btnPlayPause = findViewById(R.id.btnPlayPause)
        seekShared = findViewById(R.id.seekShared)
        videoControls = findViewById(R.id.videoControls)
        loadingRow = findViewById(R.id.loadingRow)

        videoControls.visibility = View.GONE
        setupZoomAndDividerGestures()
        setupControls()

        zoomContainer.viewTreeObserver.addOnGlobalLayoutListener(object :
            android.view.ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                if (zoomContainer.width > 0) {
                    zoomContainer.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    // afterInner must always be the FULL container width — it's the
                    // clip on afterClipContainer's own width that reveals only part of
                    // it, not a resize of the upscaled image itself.
                    afterInner.layoutParams = afterInner.layoutParams.apply { width = zoomContainer.width }
                    afterClipContainer.layoutParams = afterClipContainer.layoutParams.apply {
                        width = zoomContainer.width / 2
                    }
                    dividerLine.translationX = (zoomContainer.width / 2).toFloat()
                    dividerHandle.translationX = (zoomContainer.width / 2).toFloat() - dividerHandle.layoutParams.width / 2f
                    afterInner.requestLayout()
                    afterClipContainer.requestLayout()
                }
            }
        })

        setupPlayers()
    }

    // ------------------------------------------------------------- playback setup

    private fun setupPlayers() {
        val origUri = originalUri
        val upUri = upscaledUri
        if (origUri == null || upUri == null) {
            Toast.makeText(this, R.string.error_video_addresses_not_found, Toast.LENGTH_LONG).show()
            return
        }

        val master = ExoPlayer.Builder(this).build().apply {
            setMediaItem(MediaItem.fromUri(origUri))
            repeatMode = Player.REPEAT_MODE_ONE
            volume = 1f
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY && !masterReady) {
                        masterReady = true
                        onSideReady()
                    }
                }
            })
            prepare()
        }
        val slave = ExoPlayer.Builder(this).build().apply {
            setMediaItem(MediaItem.fromUri(upUri))
            repeatMode = Player.REPEAT_MODE_ONE
            volume = 0f // original carries the audio; upscaled is muted
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY && !slaveReady) {
                        slaveReady = true
                        onSideReady()
                    }
                }
            })
            prepare()
        }

        masterPlayer = master
        slavePlayer = slave
        beforePlayerView.player = slave  // bottom/full-width layer = upscaled
        afterPlayerView.player = master  // clipped top layer = original
    }

    private fun onSideReady() {
        if (!masterReady || !slaveReady) return
        val master = masterPlayer ?: return
        loadingRow.visibility = View.GONE
        videoControls.visibility = View.VISIBLE
        seekShared.max = master.duration.coerceAtLeast(1L).toInt()
        master.pause()
        slavePlayer?.pause()
        mainHandler.post(syncTicker)
    }

    // ------------------------------------------------------------- controls

    private fun setupControls() {
        seekShared.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                masterPlayer?.seekTo(progress.toLong())
                slavePlayer?.seekTo(progress.toLong())
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) { userIsSeeking = true }
            override fun onStopTrackingTouch(seekBar: SeekBar?) { userIsSeeking = false }
        })

        btnPlayPause.setOnClickListener {
            if (isPlaying) pauseBoth() else playBoth()
        }
    }

    private fun playBoth() {
        val master = masterPlayer ?: return
        val slave = slavePlayer ?: return
        if (!masterReady || !slaveReady) return
        // Re-align before starting so a long pause (or a prior loop-wrap
        // while paused) can't start playback already out of sync.
        slave.seekTo(master.currentPosition)
        master.play()
        slave.play()
        isPlaying = true
        btnPlayPause.setIconResource(R.drawable.ic_pause)
        mainHandler.post(seekTicker)
    }

    private fun pauseBoth() {
        masterPlayer?.pause()
        slavePlayer?.pause()
        isPlaying = false
        btnPlayPause.setIconResource(R.drawable.ic_play)
    }

    // ---------------------------------------------------------------- gestures

    private fun setupZoomAndDividerGestures() {
        scaleGestureDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                hasLastFocus = false
                zoomContainer.setLayerType(View.LAYER_TYPE_HARDWARE, null)
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                zoomContainer.setLayerType(View.LAYER_TYPE_NONE, null)
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val prevScale = scaleFactor
                scaleFactor = (scaleFactor * detector.scaleFactor).coerceIn(MIN_SCALE, MAX_SCALE)
                val scaleDelta = scaleFactor - prevScale
                if (scaleDelta != 0f) {
                    val pivotX = zoomContainer.width / 2f
                    val pivotY = zoomContainer.height / 2f
                    transX -= (detector.focusX - pivotX) * scaleDelta
                    transY -= (detector.focusY - pivotY) * scaleDelta
                }
                if (hasLastFocus) {
                    transX += detector.focusX - lastFocusX
                    transY += detector.focusY - lastFocusY
                }
                lastFocusX = detector.focusX
                lastFocusY = detector.focusY
                hasLastFocus = true
                applyZoomTransform()
                return true
            }
        })

        zoomContainer.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    isDraggingDivider = true
                    isTwoFingerPanning = false
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    isTwoFingerPanning = true
                    isDraggingDivider = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (isDraggingDivider && event.pointerCount == 1) {
                        moveDividerTo(event.x)
                    }
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    isTwoFingerPanning = false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    isDraggingDivider = false
                    isTwoFingerPanning = false
                }
            }
            true
        }
    }

    private fun applyZoomTransform() {
        zoomContainer.scaleX = scaleFactor
        zoomContainer.scaleY = scaleFactor
        zoomContainer.translationX = transX
        zoomContainer.translationY = transY
    }

    private fun moveDividerTo(x: Float) {
        val clamped = x.coerceIn(0f, zoomContainer.width.toFloat())
        afterClipContainer.layoutParams = afterClipContainer.layoutParams.apply { width = clamped.toInt() }
        afterClipContainer.requestLayout()
        dividerLine.translationX = clamped
        dividerHandle.translationX = clamped - dividerHandle.layoutParams.width / 2f
    }

    override fun onPause() {
        super.onPause()
        if (isPlaying) pauseBoth()
    }

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacksAndMessages(null)
        beforePlayerView.player = null
        afterPlayerView.player = null
        masterPlayer?.release()
        slavePlayer?.release()
        masterPlayer = null
        slavePlayer = null
    }
}

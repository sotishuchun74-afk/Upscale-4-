package com.example.upscaler

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** A single registered upscale model, either the bundled default (loaded from
 *  assets) or a user-imported custom .onnx file (stored under filesDir/models). */
data class UpscaleModel(
    val id: String,
    val name: String,
    val isBuiltIn: Boolean,
    val assetFileName: String? = null,
    val fileName: String? = null,
    val scale: Int,
    val tileSize: Int
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("isBuiltIn", isBuiltIn)
        put("assetFileName", assetFileName ?: JSONObject.NULL)
        put("fileName", fileName ?: JSONObject.NULL)
        put("scale", scale)
        put("tileSize", tileSize)
    }

    companion object {
        fun fromJson(o: JSONObject): UpscaleModel = UpscaleModel(
            id = o.getString("id"),
            name = o.getString("name"),
            isBuiltIn = o.optBoolean("isBuiltIn", false),
            assetFileName = if (o.isNull("assetFileName")) null else o.optString("assetFileName"),
            fileName = if (o.isNull("fileName")) null else o.optString("fileName"),
            scale = o.optInt("scale", 4),
            tileSize = o.optInt("tileSize", 96)
        )
    }
}

/** Persists the list of available upscale models (built-in + custom imports)
 *  to app-private storage. Importing a new model never removes existing ones;
 *  everything the user has added stays available and selectable per job. */
object ModelManager {
    private const val FILE_NAME = "models.json"
    private const val MODELS_DIR = "models"
    const val BUILT_IN_ID = "builtin_realesr_animevideov3"

    private val models = mutableListOf<UpscaleModel>()
    private var loaded = false

    @Synchronized
    private fun load(context: Context) {
        if (loaded) return
        loaded = true
        models.clear()
        val file = File(context.filesDir, FILE_NAME)
        if (file.exists()) {
            try {
                val arr = JSONArray(file.readText())
                for (i in 0 until arr.length()) {
                    models.add(UpscaleModel.fromJson(arr.getJSONObject(i)))
                }
            } catch (e: Exception) {
                // Corrupted file — fall through and re-seed the built-in model below.
            }
        }
        if (models.none { it.id == BUILT_IN_ID }) {
            models.add(
                0, UpscaleModel(
                    id = BUILT_IN_ID,
                    name = "Standart (realesr-animevideov3)",
                    isBuiltIn = true,
                    assetFileName = "realesr-animevideov3.onnx",
                    scale = 4,
                    tileSize = 96
                )
            )
            save(context)
        }
    }

    @Synchronized
    private fun save(context: Context) {
        val arr = JSONArray()
        for (m in models) arr.put(m.toJson())
        File(context.filesDir, FILE_NAME).writeText(arr.toString())
    }

    @Synchronized
    fun getModels(context: Context): List<UpscaleModel> {
        load(context)
        return models.toList()
    }

    @Synchronized
    fun getModel(context: Context, id: String): UpscaleModel? {
        load(context)
        return models.find { it.id == id } ?: models.find { it.id == BUILT_IN_ID }
    }

    /** Copies the picked .onnx file into app-private storage and registers it.
     *  Existing models (built-in or previously imported) are left untouched. */
    @Synchronized
    fun importModel(context: Context, uri: Uri, name: String, scale: Int, tileSize: Int): UpscaleModel {
        load(context)
        val dir = File(context.filesDir, MODELS_DIR)
        if (!dir.exists()) dir.mkdirs()
        val id = "custom_" + System.currentTimeMillis()
        val destFile = File(dir, "$id.onnx")
        context.contentResolver.openInputStream(uri)?.use { input ->
            destFile.outputStream().use { output -> input.copyTo(output) }
        } ?: throw RuntimeException(context.getString(R.string.error_cannot_read_model_file))

        val model = UpscaleModel(
            id = id,
            name = name,
            isBuiltIn = false,
            fileName = destFile.absolutePath,
            scale = scale.coerceIn(1, 8),
            tileSize = tileSize.coerceIn(32, 512)
        )
        models.add(model)
        save(context)
        return model
    }

    /** Removes a custom model. The built-in model can never be removed. */
    @Synchronized
    fun removeModel(context: Context, id: String) {
        load(context)
        if (id == BUILT_IN_ID) return
        val m = models.find { it.id == id } ?: return
        m.fileName?.let { File(it).delete() }
        models.removeAll { it.id == id }
        save(context)
    }

    /** Loads the raw ONNX bytes for a model, from assets (built-in) or disk (custom). */
    fun loadBytes(context: Context, model: UpscaleModel): ByteArray {
        return if (model.isBuiltIn && model.assetFileName != null) {
            context.assets.open(model.assetFileName).readBytes()
        } else {
            File(model.fileName!!).readBytes()
        }
    }
}

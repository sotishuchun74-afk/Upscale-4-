package com.example.upscaler

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class JobStatus { QUEUED, PROCESSING, PAUSED, DONE, ERROR }

data class Job(
    val id: Long,
    val videoUri: String,
    val displayName: String,
    val targetLongSide: Int,
    val maxFps: Float,
    var status: JobStatus,
    var nextFrameIndex: Int = 0,
    var frameCount: Int = 0,
    var procW: Int = 0,
    var procH: Int = 0,
    var outW: Int = 0,
    var outH: Int = 0,
    var outFps: Int = 0,
    var segmentPaths: MutableList<String> = mutableListOf(),
    var errorMessage: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("videoUri", videoUri)
        put("displayName", displayName)
        put("targetLongSide", targetLongSide)
        put("maxFps", maxFps.toDouble())
        put("status", status.name)
        put("nextFrameIndex", nextFrameIndex)
        put("frameCount", frameCount)
        put("procW", procW)
        put("procH", procH)
        put("outW", outW)
        put("outH", outH)
        put("outFps", outFps)
        put("segmentPaths", JSONArray(segmentPaths))
        put("errorMessage", errorMessage ?: JSONObject.NULL)
    }

    companion object {
        fun fromJson(o: JSONObject): Job {
            val segs = mutableListOf<String>()
            val arr = o.optJSONArray("segmentPaths")
            if (arr != null) {
                for (i in 0 until arr.length()) segs.add(arr.getString(i))
            }
            return Job(
                id = o.getLong("id"),
                videoUri = o.getString("videoUri"),
                displayName = o.getString("displayName"),
                targetLongSide = o.getInt("targetLongSide"),
                maxFps = o.getDouble("maxFps").toFloat(),
                status = JobStatus.valueOf(o.getString("status")),
                nextFrameIndex = o.optInt("nextFrameIndex", 0),
                frameCount = o.optInt("frameCount", 0),
                procW = o.optInt("procW", 0),
                procH = o.optInt("procH", 0),
                outW = o.optInt("outW", 0),
                outH = o.optInt("outH", 0),
                outFps = o.optInt("outFps", 0),
                segmentPaths = segs,
                errorMessage = if (o.isNull("errorMessage")) null else o.optString("errorMessage")
            )
        }
    }
}

/**
 * Persists the processing queue to a small JSON file in app-private storage,
 * so it survives the app being closed, the service being killed, or even a
 * device reboot — everything needed to resume (source URI permission, the
 * frame index reached, and the already-finished video segments) is saved
 * to disk after every meaningful step.
 */
object QueueManager {
    private const val FILE_NAME = "queue.json"
    private val jobs = mutableListOf<Job>()
    private var loaded = false

    @Synchronized
    fun load(context: Context) {
        if (loaded) return
        loaded = true
        jobs.clear()
        val file = File(context.filesDir, FILE_NAME)
        if (!file.exists()) return
        try {
            val text = file.readText()
            val arr = JSONArray(text)
            for (i in 0 until arr.length()) {
                jobs.add(Job.fromJson(arr.getJSONObject(i)))
            }
        } catch (e: Exception) {
            // Corrupted queue file — start fresh rather than crash the app.
        }
    }

    @Synchronized
    private fun save(context: Context) {
        val arr = JSONArray()
        for (job in jobs) arr.put(job.toJson())
        File(context.filesDir, FILE_NAME).writeText(arr.toString())
    }

    @Synchronized
    fun getJobs(context: Context): List<Job> {
        load(context)
        return jobs.toList()
    }

    @Synchronized
    fun addJob(context: Context, videoUri: String, displayName: String, targetLongSide: Int, maxFps: Float): Job {
        load(context)
        val job = Job(
            id = System.currentTimeMillis(),
            videoUri = videoUri,
            displayName = displayName,
            targetLongSide = targetLongSide,
            maxFps = maxFps,
            status = JobStatus.QUEUED
        )
        jobs.add(job)
        save(context)
        return job
    }

    @Synchronized
    fun removeJob(context: Context, id: Long) {
        load(context)
        val job = jobs.find { it.id == id }
        job?.segmentPaths?.forEach { File(it).delete() }
        jobs.removeAll { it.id == id }
        save(context)
    }

    @Synchronized
    fun updateJob(context: Context, job: Job) {
        load(context)
        val idx = jobs.indexOfFirst { it.id == job.id }
        if (idx >= 0) jobs[idx] = job else jobs.add(job)
        save(context)
    }

    /** Next job that should run: whichever is furthest along in the FIFO
     *  order among QUEUED/PAUSED jobs (a PAUSED job resumes before any
     *  later-added QUEUED one, since it keeps its original list position). */
    @Synchronized
    fun nextRunnable(context: Context): Job? {
        load(context)
        return jobs.firstOrNull { it.status == JobStatus.QUEUED || it.status == JobStatus.PAUSED }
    }
}

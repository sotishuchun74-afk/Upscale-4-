package com.example.upscaler

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

/**
 * Base class for every top-level screen reachable from the bottom
 * navigation bar (Home / History / Output Gallery / Community).
 * Call [setupBottomNav] after setContentView() with the id of the
 * tab that represents the current screen.
 */
abstract class BaseNavActivity : AppCompatActivity() {

    protected fun setupBottomNav(selectedItemId: Int) {
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav) ?: return
        bottomNav.selectedItemId = selectedItemId
        bottomNav.setOnItemSelectedListener { item ->
            if (item.itemId == selectedItemId) {
                true
            } else {
                val target: Class<out AppCompatActivity>? = when (item.itemId) {
                    R.id.nav_home -> MainActivity::class.java
                    R.id.nav_history -> HistoryActivity::class.java
                    R.id.nav_gallery -> GalleryActivity::class.java
                    R.id.nav_community -> CommunityActivity::class.java
                    R.id.nav_settings -> SettingsActivity::class.java
                    else -> null
                }
                if (target != null) {
                    startActivity(Intent(this, target).apply {
                        flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    })
                    overridePendingTransition(0, 0)
                }
                true
            }
        }
    }
}

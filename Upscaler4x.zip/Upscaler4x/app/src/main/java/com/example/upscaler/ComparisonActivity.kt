package com.example.upscaler

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ScaleGestureDetector
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/**
 * Zoom Compare screen (2-vazifa): a before/after slider between the original
 * and the upscaled video, with synchronized pinch-zoom/pan on both layers.
 *
 * Two modes:
 *  - Video: both videos play/seek together off a single shared SeekBar.
 *  - Freeze-frame: a single still frame from each video (at the scrubbed
 *    position) is compared pixel-for-pixel — lighter than keeping two videos
 *    in perfect lockstep while also zoomed in, and better for spotting detail.
 *
 * Video playback uses TextureView + MediaPlayer instead of VideoView (which is
 * backed by SurfaceView). SurfaceView composites as a separate "hole punch"
 * window, so it doesn't reliably follow this screen's View-hierarchy
 * transforms (clipChildren clipping, scaleX/scaleY/translationX/Y pinch-zoom) —
 * that caused the compare clip to sometimes show the full frame regardless of
 * the slider, and the surface position to lag a frame behind the zoom
 * transform, causing jitter. TextureView renders into the normal View
 * hierarchy like any other View, so both issues go away. No new Gradle
 * dependency is required; ExoPlayer/media3 would give frame-accurate seeking
 * in Video mode at the cost of a new dependency — flagging that trade-off
 * here rather than adding it unasked.
 */
class ComparisonActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ORIGINAL_URI = "extra_original_uri"
        const val EXTRA_UPSCALED_URI = "extra_upscaled_uri"
        const val EXTRA_TITLE = "extra_title"
        private const val MIN_SCALE = 1f
        private const val MAX_SCALE = 6f
    }

    private lateinit var zoomContainer: FrameLayout
    private lateinit var beforeImage: ImageView
    private lateinit var afterImage: ImageView
    private lateinit var beforeVideo: TextureView
    private lateinit var afterVideo: TextureView
    private lateinit var afterClipContainer: FrameLayout
    private lateinit var afterInner: FrameLayout
    private lateinit var dividerLine: View
    private lateinit var dividerHandle: View
    private lateinit var btnPlayPause: MaterialButton
    private lateinit var seekShared: SeekBar
    private lateinit var videoControls: View

    private var originalUri: Uri? = null
    private var upscaledUri: Uri? = null

    private var isFreezeFrameMode = false
    private var isPlaying = false
    private var userIsSeeking = false

    // --- Video-mode players. TextureView (not VideoView/SurfaceView) so the
    // rendered frame is a normal View-hierarchy citizen: clipChildren and the
    // pinch-zoom scaleX/scaleY/translationX/Y transforms below apply to it
    // correctly and without a frame of lag. ---
    private var beforePlayer: MediaPlayer? = null
    private var afterPlayer: MediaPlayer? = null
    private var beforeDurationMs = 0
    private var afterDurationMs = 0

    private var beforeRetriever: MediaMetadataRetriever? = null
    private var afterRetriever: MediaMetadataRetriever? = null
    private var freezeDurationMs = 0L

    private val mainHandler = Handler(Looper.getMainLooper())
    private val progressTicker = object : Runnable {
        override fun run() {
            if (isPlaying && !userIsSeeking) {
                seekShared.progress = beforePlayer?.currentPosition ?: 0
                mainHandler.postDelayed(this, 200)
            }
        }
    }

    // --- Pinch-zoom / pan state, applied to zoomContainer so both layers move together ---
    private var scaleFactor = 1f
    private var transX = 0f
    private var transY = 0f
    private var activePointerLastX = 0f
    private var activePointerLastY = 0f
    private var isTwoFingerPanning = false
    private var isDraggingDivider = false
    private lateinit var scaleGestureDetector: ScaleGestureDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comparison)

        originalUri = intent.getStringExtra(EXTRA_ORIGINAL_URI)?.let { Uri.parse(it) }
        upscaledUri = intent.getStringExtra(EXTRA_UPSCALED_URI)?.let { Uri.parse(it) }

        findViewById<TextView>(R.id.tvCompareTitle).text = intent.getStringExtra(EXTRA_TITLE) ?: ""
        findViewById<MaterialButton>(R.id.btnCloseCompare).setOnClickListener { finish() }

        zoomContainer = findViewById(R.id.zoomContainer)
        beforeImage = findViewById(R.id.beforeImage)
        afterImage = findViewById(R.id.afterImage)
        beforeVideo = findViewById(R.id.beforeVideo)
        afterVideo = findViewById(R.id.afterVideo)
        afterClipContainer = findViewById(R.id.afterClipContainer)
        afterInner = findViewById(R.id.afterInner)
        dividerLine = findViewById(R.id.dividerLine)
        dividerHandle = findViewById(R.id.dividerHandle)
        btnPlayPause = findViewById(R.id.btnPlayPause)
        seekShared = findViewById(R.id.seekShared)
        videoControls = findViewById(R.id.videoControls)

        setupZoomAndDividerGestures()
        setupModeToggle()
        setupVideoMode()

        zoomContainer.viewTreeObserver.addOnGlobalLayoutListener(object :
            android.view.ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                if (zoomContainer.width > 0) {
                    zoomContainer.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    // afterInner must always be the FULL container width — it's the
                    // clip on afterClipContainer's own width that reveals only part of
                    // it, not a resize of the upscaled image/video itself.
                    afterInner.layoutParams = afterInner.layoutParams.apply { width = zoomContainer.width }
                    afterClipContainer.layoutParams = afterClipContainer.layoutParams.apply {
                        width = zoomContainer.width / 2
                    }
                    dividerLine.translationX = (zoomContainer.width / 2).toFloat()
                    dividerHandle.translationX = (zoomContainer.width / 2).toFloat() - dividerHandle.layoutParams.width / 2f
                    afterInner.requestLayout()
                    afterClipContainer.requestLayout()
                }
            }
        })

        // Default to Video mode.
        findViewById<com.google.android.material.button.MaterialButtonToggleGroup>(R.id.toggleMode)
            .check(R.id.btnModeVideo)
    }

    // ---------------------------------------------------------------- gestures

    private fun setupZoomAndDividerGestures() {
        scaleGestureDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val prevScale = scaleFactor
                scaleFactor = (scaleFactor * detector.scaleFactor).coerceIn(MIN_SCALE, MAX_SCALE)
                val scaleDelta = scaleFactor - prevScale
                if (scaleDelta != 0f) {
                    // Keep the point under the two fingers visually fixed: since
                    // scaleX/scaleY pivot around the view center by default, any
                    // point offset from center drifts by (offset * scaleDelta)
                    // when scale changes. Counteract that in translation so the
                    // zoom appears centered on the pinch focus, not the view
                    // center — otherwise the image "jumps" on every scale step.
                    val pivotX = zoomContainer.width / 2f
                    val pivotY = zoomContainer.height / 2f
                    transX -= (detector.focusX - pivotX) * scaleDelta
                    transY -= (detector.focusY - pivotY) * scaleDelta
                }
                applyZoomTransform()
                return true
            }
        })

        zoomContainer.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    activePointerLastX = event.x
                    activePointerLastY = event.y
                    isDraggingDivider = true
                    isTwoFingerPanning = false
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    isTwoFingerPanning = true
                    isDraggingDivider = false
                    activePointerLastX = averageX(event)
                    activePointerLastY = averageY(event)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (isTwoFingerPanning && event.pointerCount >= 2) {
                        // Two fingers: pan both layers together (same Matrix state).
                        val cx = averageX(event)
                        val cy = averageY(event)
                        transX += cx - activePointerLastX
                        transY += cy - activePointerLastY
                        activePointerLastX = cx
                        activePointerLastY = cy
                        applyZoomTransform()
                    } else if (isDraggingDivider && event.pointerCount == 1) {
                        // One finger: drag the before/after slider. Touch coordinates
                        // arrive already in zoomContainer's local (untransformed) space.
                        moveDividerTo(event.x)
                    }
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    isTwoFingerPanning = false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    isDraggingDivider = false
                    isTwoFingerPanning = false
                }
            }
            true
        }
    }

    private fun averageX(event: MotionEvent): Float {
        var sum = 0f
        for (i in 0 until event.pointerCount) sum += event.getX(i)
        return sum / event.pointerCount
    }

    private fun averageY(event: MotionEvent): Float {
        var sum = 0f
        for (i in 0 until event.pointerCount) sum += event.getY(i)
        return sum / event.pointerCount
    }

    private fun applyZoomTransform() {
        zoomContainer.scaleX = scaleFactor
        zoomContainer.scaleY = scaleFactor
        zoomContainer.translationX = transX
        zoomContainer.translationY = transY
    }

    private fun moveDividerTo(x: Float) {
        val clamped = x.coerceIn(0f, zoomContainer.width.toFloat())
        afterClipContainer.layoutParams = afterClipContainer.layoutParams.apply { width = clamped.toInt() }
        afterClipContainer.requestLayout()
        dividerLine.translationX = clamped
        dividerHandle.translationX = clamped - dividerHandle.layoutParams.width / 2f
    }

    // ------------------------------------------------------------------ modes

    private fun setupModeToggle() {
        findViewById<com.google.android.material.button.MaterialButtonToggleGroup>(R.id.toggleMode)
            .addOnButtonCheckedListener { _, checkedId, isChecked ->
                if (!isChecked) return@addOnButtonCheckedListener
                when (checkedId) {
                    R.id.btnModeVideo -> switchToVideoMode()
                    R.id.btnModeFreeze -> switchToFreezeFrameMode()
                }
            }
    }

    private fun setupVideoMode() {
        originalUri?.let { uri ->
            setupPlayer(beforeVideo, uri, mute = false, assign = { beforePlayer = it }) { mp ->
                beforeDurationMs = mp.duration
                maybeUpdateSeekMax()
            }
        }
        // Mute the "after" (upscaled) layer's audio. Both players decode the
        // same underlying audio track, so with both unmuted the user hears an
        // echo; only one side should be audible.
        upscaledUri?.let { uri ->
            setupPlayer(afterVideo, uri, mute = true, assign = { afterPlayer = it }) { mp ->
                afterDurationMs = mp.duration
                maybeUpdateSeekMax()
            }
        }

        seekShared.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                if (isFreezeFrameMode) {
                    updateFreezeFrames(progress.toLong())
                } else {
                    beforePlayer?.seekTo(progress)
                    afterPlayer?.seekTo(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) { userIsSeeking = true }
            override fun onStopTrackingTouch(seekBar: SeekBar?) { userIsSeeking = false }
        })

        btnPlayPause.setOnClickListener {
            if (isPlaying) pauseBoth() else playBoth()
        }
    }

    /**
     * Wires a TextureView up to a MediaPlayer rendering [uri]. The MediaPlayer
     * is created once the TextureView's SurfaceTexture is available (or
     * immediately, if it already is) and handed to [assign] as soon as it
     * exists so playback controls can reach it; [onReady] fires once the
     * player has finished preparing (duration known, safe to seek/start).
     */
    private fun setupPlayer(
        textureView: TextureView,
        uri: Uri,
        mute: Boolean,
        assign: (MediaPlayer?) -> Unit,
        onReady: (MediaPlayer) -> Unit
    ) {
        fun start(surfaceTexture: SurfaceTexture) {
            val player = MediaPlayer()
            try {
                player.setDataSource(this@ComparisonActivity, uri)
                player.setSurface(Surface(surfaceTexture))
                player.isLooping = true
                if (mute) player.setVolume(0f, 0f)
                player.setOnPreparedListener { mp -> onReady(mp) }
                player.prepareAsync()
                assign(player)
            } catch (e: Exception) {
                assign(null)
            }
        }

        if (textureView.isAvailable) {
            textureView.surfaceTexture?.let { start(it) }
        }
        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                if (!textureView.isAvailable) return
                start(surface)
            }
            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
        }
    }

    private fun maybeUpdateSeekMax() {
        if (beforeDurationMs > 0 && afterDurationMs > 0) {
            seekShared.max = minOf(beforeDurationMs, afterDurationMs)
        }
    }

    private fun playBoth() {
        beforePlayer?.start()
        afterPlayer?.start()
        isPlaying = true
        btnPlayPause.setIconResource(R.drawable.ic_pause)
        mainHandler.post(progressTicker)
    }

    private fun pauseBoth() {
        beforePlayer?.pause()
        afterPlayer?.pause()
        isPlaying = false
        btnPlayPause.setIconResource(R.drawable.ic_play)
    }

    private fun switchToVideoMode() {
        isFreezeFrameMode = false
        videoControls.visibility = View.VISIBLE
        btnPlayPause.visibility = View.VISIBLE
        beforeImage.visibility = View.GONE
        afterImage.visibility = View.GONE
        beforeVideo.visibility = View.VISIBLE
        afterVideo.visibility = View.VISIBLE
        maybeUpdateSeekMax()
    }

    private fun switchToFreezeFrameMode() {
        pauseBoth()
        isFreezeFrameMode = true
        videoControls.visibility = View.VISIBLE
        btnPlayPause.visibility = View.GONE
        beforeVideo.visibility = View.GONE
        afterVideo.visibility = View.GONE
        beforeImage.visibility = View.VISIBLE
        afterImage.visibility = View.VISIBLE

        ensureRetrievers()
        val beforeDur = beforeRetriever?.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        val afterDur = afterRetriever?.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        freezeDurationMs = minOf(beforeDur, afterDur).coerceAtLeast(1L)
        seekShared.max = freezeDurationMs.toInt()
        updateFreezeFrames(seekShared.progress.toLong().coerceAtMost(freezeDurationMs))
    }

    private fun ensureRetrievers() {
        if (beforeRetriever == null) {
            beforeRetriever = MediaMetadataRetriever().apply {
                try { originalUri?.let { setDataSource(this@ComparisonActivity, it) } } catch (e: Exception) { }
            }
        }
        if (afterRetriever == null) {
            afterRetriever = MediaMetadataRetriever().apply {
                try { upscaledUri?.let { setDataSource(this@ComparisonActivity, it) } } catch (e: Exception) { }
            }
        }
    }

    /** Grabs one frame from each video at [positionMs] and shows them as static
     *  bitmaps — a lighter, more precise way to pixel-compare than keeping two
     *  videos zoomed in and perfectly seeked in lockstep in real time. */
    private fun updateFreezeFrames(positionMs: Long) {
        ensureRetrievers()
        val timeUs = positionMs * 1000L
        Thread {
            val beforeBmp: Bitmap? = try {
                beforeRetriever?.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
            } catch (e: Exception) { null }
            val afterBmp: Bitmap? = try {
                afterRetriever?.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
            } catch (e: Exception) { null }
            mainHandler.post {
                beforeBmp?.let { beforeImage.setImageBitmap(it) }
                afterBmp?.let { afterImage.setImageBitmap(it) }
            }
        }.start()
    }

    override fun onPause() {
        super.onPause()
        if (isPlaying) pauseBoth()
    }

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacksAndMessages(null)
        beforePlayer?.release()
        afterPlayer?.release()
        beforePlayer = null
        afterPlayer = null
        beforeRetriever?.release()
        afterRetriever?.release()
    }
}

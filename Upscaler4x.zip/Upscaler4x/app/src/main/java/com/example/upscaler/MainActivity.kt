package com.example.upscaler

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.nio.FloatBuffer

class MainActivity : AppCompatActivity() {

    private lateinit var imgOriginal: ImageView
    private lateinit var imgResult: ImageView
    private lateinit var btnPick: Button
    private lateinit var btnUpscale: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var tvStatus: TextView

    private var originalBitmap: Bitmap? = null
    private var ortEnv: OrtEnvironment? = null
    private var ortSession: OrtSession? = null

    // Model settings (must match the ONNX model this project ships with)
    private val TILE_SIZE = 96
    private val OVERLAP = 8
    private val SCALE = 4
    private val MODEL_FILE = "4x-HFA2kLUDVAESwinIR-light.onnx"

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                val bmp = MediaStore.Images.Media.getBitmap(contentResolver, uri)
                originalBitmap = bmp.copy(Bitmap.Config.ARGB_8888, false)
                imgOriginal.setImageBitmap(originalBitmap)
                imgResult.setImageBitmap(null)
                btnUpscale.isEnabled = true
                tvStatus.text = "Tanlandi: ${originalBitmap!!.width}x${originalBitmap!!.height}"
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imgOriginal = findViewById(R.id.imgOriginal)
        imgResult = findViewById(R.id.imgResult)
        btnPick = findViewById(R.id.btnPick)
        btnUpscale = findViewById(R.id.btnUpscale)
        progressBar = findViewById(R.id.progressBar)
        tvStatus = findViewById(R.id.tvStatus)

        btnPick.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        btnUpscale.setOnClickListener {
            val bmp = originalBitmap
            if (bmp == null) {
                Toast.makeText(this, "Avval rasm tanlang", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            runUpscale(bmp)
        }
    }

    private fun runUpscale(bitmap: Bitmap) {
        setBusy(true, "Model yuklanmoqda...")
        Thread {
            try {
                ensureSession()
                setBusyOnUi(true, "Kattalashtirilmoqda... (0%)")

                val result = upscaleWithTiling(bitmap) { done, total ->
                    val pct = (done * 100) / total
                    setBusyOnUi(true, "Kattalashtirilmoqda... ($pct%)")
                }

                runOnUiThread {
                    imgResult.setImageBitmap(result)
                    setBusy(false, "Tayyor! ${result.width}x${result.height}")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false, "Xatolik: ${e.message}")
                }
            }
        }.start()
    }

    private fun setBusyOnUi(busy: Boolean, msg: String) {
        runOnUiThread { setBusy(busy, msg) }
    }

    private fun setBusy(busy: Boolean, msg: String) {
        progressBar.visibility = if (busy) android.view.View.VISIBLE else android.view.View.GONE
        btnUpscale.isEnabled = !busy
        btnPick.isEnabled = !busy
        tvStatus.text = msg
    }

    private fun ensureSession() {
        if (ortSession != null) return
        val env = OrtEnvironment.getEnvironment()
        val bytes = assets.open(MODEL_FILE).readBytes()
        val options = OrtSession.SessionOptions()
        val session = env.createSession(bytes, options)
        ortEnv = env
        ortSession = session
    }

    /**
     * Splits the image into tiles, runs the model on each tile, and stitches
     * the upscaled tiles back together. This keeps memory usage bounded so
     * the model can run on typical phones even for larger input images.
     */
    private fun upscaleWithTiling(
        input: Bitmap,
        onProgress: (Int, Int) -> Unit
    ): Bitmap {
        val w = input.width
        val h = input.height
        val outBitmap = Bitmap.createBitmap(w * SCALE, h * SCALE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outBitmap)

        val tilesX = (w + TILE_SIZE - 1) / TILE_SIZE
        val tilesY = (h + TILE_SIZE - 1) / TILE_SIZE
        val totalTiles = tilesX * tilesY
        var doneTiles = 0

        var y = 0
        while (y < h) {
            val tileH = minOf(TILE_SIZE, h - y)
            var x = 0
            while (x < w) {
                val tileW = minOf(TILE_SIZE, w - x)

                val padLeft = minOf(OVERLAP, x)
                val padTop = minOf(OVERLAP, y)
                val padRight = minOf(OVERLAP, w - (x + tileW))
                val padBottom = minOf(OVERLAP, h - (y + tileH))

                val cropX = x - padLeft
                val cropY = y - padTop
                val cropW = tileW + padLeft + padRight
                val cropH = tileH + padTop + padBottom

                val tileBitmap = Bitmap.createBitmap(input, cropX, cropY, cropW, cropH)
                val outTile = runModelOnTile(tileBitmap)

                val srcLeft = padLeft * SCALE
                val srcTop = padTop * SCALE
                val srcW = tileW * SCALE
                val srcH = tileH * SCALE
                val finalTile = Bitmap.createBitmap(outTile, srcLeft, srcTop, srcW, srcH)

                canvas.drawBitmap(finalTile, (x * SCALE).toFloat(), (y * SCALE).toFloat(), null)

                doneTiles++
                onProgress(doneTiles, totalTiles)

                x += tileW
            }
            y += tileH
        }
        return outBitmap
    }

    private fun runModelOnTile(bitmap: Bitmap): Bitmap {
        val env = ortEnv!!
        val session = ortSession!!

        val inputTensor = bitmapToTensor(bitmap, env)
        inputTensor.use { tensor ->
            val inputs = mapOf("input" to tensor)
            session.run(inputs).use { result ->
                val outputTensor = result[0] as OnnxTensor
                return tensorToBitmap(outputTensor)
            }
        }
    }

    private fun bitmapToTensor(bitmap: Bitmap, env: OrtEnvironment): OnnxTensor {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val floatBuffer = FloatBuffer.allocate(3 * w * h)
        val rArr = FloatArray(w * h)
        val gArr = FloatArray(w * h)
        val bArr = FloatArray(w * h)
        for (i in 0 until w * h) {
            val p = pixels[i]
            rArr[i] = ((p shr 16) and 0xFF) / 255f
            gArr[i] = ((p shr 8) and 0xFF) / 255f
            bArr[i] = (p and 0xFF) / 255f
        }
        floatBuffer.put(rArr)
        floatBuffer.put(gArr)
        floatBuffer.put(bArr)
        floatBuffer.rewind()

        val shape = longArrayOf(1, 3, h.toLong(), w.toLong())
        return OnnxTensor.createTensor(env, floatBuffer, shape)
    }

    private fun tensorToBitmap(tensor: OnnxTensor): Bitmap {
        val shape = tensor.info.shape
        val h = shape[2].toInt()
        val w = shape[3].toInt()
        val size = h * w

        val buffer = tensor.floatBuffer
        val rArr = FloatArray(size)
        val gArr = FloatArray(size)
        val bArr = FloatArray(size)
        buffer.get(rArr)
        buffer.get(gArr)
        buffer.get(bArr)

        val pixels = IntArray(size)
        for (i in 0 until size) {
            val r = (rArr[i].coerceIn(0f, 1f) * 255).toInt()
            val g = (gArr[i].coerceIn(0f, 1f) * 255).toInt()
            val b = (bArr[i].coerceIn(0f, 1f) * 255).toInt()
            pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }

        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, w, 0, 0, w, h)
        return bmp
    }

    override fun onDestroy() {
        super.onDestroy()
        ortSession?.close()
        ortEnv?.close()
    }
}

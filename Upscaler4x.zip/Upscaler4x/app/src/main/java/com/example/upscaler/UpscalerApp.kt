package com.example.upscaler

import android.app.Application

class UpscalerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        SettingsManager.applyThemeMode(SettingsManager.getThemeMode(this))
    }
}

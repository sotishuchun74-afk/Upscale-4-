"""
Converts realesr-animevideov3.pth (SRVGGNetCompact architecture) into an
ONNX file compatible with the Android app's existing input/output tensor
convention (NCHW, float32, values normalized 0-1, tensor names "input"/"output").

This script needs internet access (to install torch/onnx), which is why it
runs inside GitHub Actions rather than being pre-converted locally.
"""
import torch
from torch import nn
import torch.nn.functional as F


class SRVGGNetCompact(nn.Module):
    def __init__(self, num_in_ch=3, num_out_ch=3, num_feat=64, num_conv=16, upscale=4):
        super().__init__()
        self.upscale = upscale
        self.body = nn.ModuleList()
        self.body.append(nn.Conv2d(num_in_ch, num_feat, 3, 1, 1))
        self.body.append(nn.PReLU(num_parameters=num_feat))
        for _ in range(num_conv):
            self.body.append(nn.Conv2d(num_feat, num_feat, 3, 1, 1))
            self.body.append(nn.PReLU(num_parameters=num_feat))
        self.body.append(nn.Conv2d(num_feat, num_out_ch * upscale * upscale, 3, 1, 1))
        self.upsampler = nn.PixelShuffle(upscale)

    def forward(self, x):
        out = x
        for layer in self.body:
            out = layer(out)
        out = self.upsampler(out)
        base = F.interpolate(x, scale_factor=self.upscale, mode='nearest')
        return out + base


def main():
    model = SRVGGNetCompact(num_in_ch=3, num_out_ch=3, num_feat=64, num_conv=16, upscale=4)

    ckpt = torch.load('Upscaler4x/model_source/realesr-animevideov3.pth', map_location='cpu')
    state_dict = ckpt['params'] if 'params' in ckpt else ckpt
    model.load_state_dict(state_dict, strict=True)
    model.eval()

    dummy = torch.rand(1, 3, 64, 64)
    out_path = 'Upscaler4x/app/src/main/assets/realesr-animevideov3.onnx'

    torch.onnx.export(
        model,
        dummy,
        out_path,
        input_names=['input'],
        output_names=['output'],
        dynamic_axes={
            'input': {0: 'batch_size', 2: 'height', 3: 'width'},
            'output': {0: 'batch_size', 2: 'height', 3: 'width'},
        },
        opset_version=12,
        dynamo=False,
    )

    # Ensure weights are embedded in a single file (no external .data file),
    # since the Android app loads the model from an in-memory byte array.
    import onnx
    onnx_model = onnx.load(out_path, load_external_data=True)
    onnx.save(onnx_model, out_path, save_as_external_data=False)

    print(f'Exported ONNX model to {out_path}')


if __name__ == '__main__':
    main()

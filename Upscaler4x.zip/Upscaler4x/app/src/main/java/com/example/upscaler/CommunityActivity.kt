package com.example.upscaler

import android.os.Bundle
import android.widget.TextView

class CommunityActivity : BaseNavActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_placeholder)
        findViewById<TextView>(R.id.tvPlaceholderTitle).setText(R.string.community_title)
        findViewById<TextView>(R.id.tvPlaceholderBody).setText(R.string.community_empty)
        setupBottomNav(R.id.nav_community)
    }
}
